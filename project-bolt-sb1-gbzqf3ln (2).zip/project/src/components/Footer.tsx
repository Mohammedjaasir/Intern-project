import React from 'react';
import { Code2, Mail, Phone, MapPin, Github, Linkedin, Twitter, Instagram, Heart, Star, Sparkles, Rocket } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-black/30 backdrop-blur-sm border-t border-white/10 relative overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0 opacity-5">
        <img 
          src="https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=1920&h=600&fit=crop"
          alt="Footer background"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-slate-900/95 via-purple-900/95 to-slate-900/95"></div>
      </div>

      {/* Floating Particles */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(15)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-gradient-to-r from-cyan-400 to-purple-500 rounded-full opacity-30 animate-twinkle"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${2 + Math.random() * 2}s`
            }}
          />
        ))}
      </div>

      <div className="container mx-auto px-6 py-16 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Enhanced Company Info */}
          <div className="space-y-6 group">
            <div className="flex items-center space-x-4">
              <div className="relative">
                <div className="p-3 bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-600 rounded-2xl group-hover:scale-110 transition-all duration-500 shadow-lg shadow-cyan-500/25">
                  <Code2 className="w-8 h-8 text-white" />
                </div>
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center animate-bounce">
                  <Sparkles className="w-2 h-2 text-white" />
                </div>
              </div>
              <div>
                <h3 className="text-2xl font-bold bg-gradient-to-r from-white via-cyan-200 to-purple-200 bg-clip-text text-transparent">
                  CodeBind
                </h3>
                <p className="text-sm text-cyan-300 font-medium">Technologies</p>
              </div>
            </div>
            
            <p className="text-gray-300 leading-relaxed text-lg group-hover:text-gray-200 transition-colors duration-300">
              Empowering the next generation of developers through innovative internship programs and hands-on learning experiences. 
              <span className="text-cyan-400 font-semibold"> Join 1000+ successful graduates!</span>
            </p>
            
            <div className="flex space-x-4">
              {[
                { icon: Github, href: '#', color: 'hover:text-gray-300' },
                { icon: Linkedin, href: '#', color: 'hover:text-blue-400' },
                { icon: Twitter, href: '#', color: 'hover:text-cyan-400' },
                { icon: Instagram, href: '#', color: 'hover:text-pink-400' }
              ].map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  className={`p-3 bg-white/10 rounded-2xl text-gray-400 ${social.color} transition-all duration-300 hover:scale-110 hover:bg-white/20 group`}
                >
                  <social.icon className="w-6 h-6" />
                </a>
              ))}
            </div>
          </div>

          {/* Enhanced Quick Links */}
          <div className="space-y-6">
            <h4 className="text-2xl font-bold text-white flex items-center space-x-2">
              <Rocket className="w-6 h-6 text-cyan-400" />
              <span>Quick Links</span>
            </h4>
            <ul className="space-y-4">
              {[
                'About Us',
                'Internship Programs',
                'Success Stories',
                'Partner Companies',
                'Blog & Resources',
                'Career Guidance'
              ].map((link, index) => (
                <li key={index}>
                  <a
                    href="#"
                    className="group flex items-center space-x-3 text-gray-300 hover:text-cyan-300 transition-all duration-300 text-lg"
                  >
                    <div className="w-2 h-2 bg-gradient-to-r from-cyan-400 to-purple-400 rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                    <span className="group-hover:translate-x-2 transition-transform duration-300">{link}</span>
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Enhanced Programs */}
          <div className="space-y-6">
            <h4 className="text-2xl font-bold text-white flex items-center space-x-2">
              <Star className="w-6 h-6 text-purple-400" />
              <span>Programs</span>
            </h4>
            <ul className="space-y-4">
              {[
                { name: 'Full-Stack Development', badge: '🔥 Popular' },
                { name: 'Mobile App Development', badge: '📱 Trending' },
                { name: 'AI & Machine Learning', badge: '🤖 New' },
                { name: 'DevOps & Cloud', badge: '☁️ Hot' },
                { name: 'UI/UX Design', badge: '🎨 Creative' },
                { name: 'Blockchain Development', badge: '⛓️ Future' }
              ].map((program, index) => (
                <li key={index}>
                  <a
                    href="#"
                    className="group flex flex-col space-y-1 text-gray-300 hover:text-purple-300 transition-all duration-300"
                  >
                    <span className="text-lg group-hover:translate-x-2 transition-transform duration-300">
                      {program.name}
                    </span>
                    <span className="text-xs text-gray-500 group-hover:text-purple-400 transition-colors duration-300">
                      {program.badge}
                    </span>
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Enhanced Contact Info */}
          <div className="space-y-6">
            <h4 className="text-2xl font-bold text-white flex items-center space-x-2">
              <Heart className="w-6 h-6 text-pink-400 animate-pulse" />
              <span>Contact Us</span>
            </h4>
            <div className="space-y-6">
              {[
                {
                  icon: Mail,
                  label: 'Email',
                  value: 'hello@codebind.tech',
                  href: 'mailto:hello@codebind.tech',
                  color: 'text-cyan-400 hover:text-cyan-300'
                },
                {
                  icon: Phone,
                  label: 'Phone',
                  value: '+91 98765 43210',
                  href: 'tel:+919876543210',
                  color: 'text-green-400 hover:text-green-300'
                },
                {
                  icon: MapPin,
                  label: 'Location',
                  value: 'Bangalore, Karnataka, India',
                  href: '#',
                  color: 'text-purple-400 hover:text-purple-300'
                }
              ].map((contact, index) => (
                <div key={index} className="group flex items-start space-x-4">
                  <div className="p-2 bg-gradient-to-r from-white/10 to-white/5 rounded-xl group-hover:scale-110 transition-transform duration-300">
                    <contact.icon className={`w-5 h-5 ${contact.color.split(' ')[0]}`} />
                  </div>
                  <div>
                    <p className="text-gray-400 text-sm font-medium">{contact.label}</p>
                    <a
                      href={contact.href}
                      className={`${contact.color} transition-colors duration-300 text-lg font-medium group-hover:underline`}
                    >
                      {contact.value}
                    </a>
                  </div>
                </div>
              ))}
            </div>

            {/* Newsletter Signup */}
            <div className="p-6 bg-gradient-to-r from-white/10 to-white/5 rounded-2xl border border-white/20 hover:border-white/30 transition-all duration-300">
              <h5 className="text-lg font-bold text-white mb-3 flex items-center space-x-2">
                <Sparkles className="w-5 h-5 text-yellow-400" />
                <span>Stay Updated!</span>
              </h5>
              <p className="text-gray-300 text-sm mb-4">Get the latest updates on programs and opportunities.</p>
              <div className="flex space-x-2">
                <input
                  type="email"
                  placeholder="Your email"
                  className="flex-1 px-4 py-2 bg-white/10 border border-white/20 rounded-xl text-white placeholder-gray-400 focus:outline-none focus:border-cyan-400 transition-colors duration-300"
                />
                <button className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-purple-600 text-white rounded-xl hover:from-cyan-600 hover:to-purple-700 transition-all duration-300 hover:scale-105">
                  Subscribe
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Enhanced Bottom Bar */}
        <div className="mt-16 pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between">
          <p className="text-gray-400 text-lg flex items-center space-x-2">
            <span>© 2025 CodeBind Technologies. Made with</span>
            <Heart className="w-5 h-5 text-red-400 animate-pulse" />
            <span>in India. All rights reserved.</span>
          </p>
          <div className="flex space-x-8 mt-6 md:mt-0">
            {[
              'Privacy Policy',
              'Terms of Service',
              'Cookie Policy',
              'Refund Policy'
            ].map((link, index) => (
              <a
                key={index}
                href="#"
                className="text-gray-400 hover:text-cyan-300 text-lg transition-colors duration-300 hover:underline"
              >
                {link}
              </a>
            ))}
          </div>
        </div>

        {/* Success Stats */}
        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-6">
          {[
            { number: '1000+', label: 'Students Placed', icon: '🎓' },
            { number: '100+', label: 'Partner Companies', icon: '🏢' },
            { number: '98%', label: 'Success Rate', icon: '📈' },
            { number: '50+', label: 'Expert Mentors', icon: '👨‍🏫' }
          ].map((stat, index) => (
            <div
              key={index}
              className="text-center p-6 bg-gradient-to-r from-white/5 to-white/10 rounded-2xl border border-white/10 hover:border-white/20 hover:scale-105 transition-all duration-300 group"
            >
              <div className="text-4xl mb-2 group-hover:scale-125 transition-transform duration-300">
                {stat.icon}
              </div>
              <div className="text-3xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent mb-1">
                {stat.number}
              </div>
              <div className="text-gray-400 text-sm font-medium">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>

      <style jsx>{`
        @keyframes twinkle {
          0%, 100% {
            opacity: 0.3;
            transform: scale(1);
          }
          50% {
            opacity: 1;
            transform: scale(1.5);
          }
        }
        
        .animate-twinkle {
          animation: twinkle 2s ease-in-out infinite;
        }
      `}</style>
    </footer>
  );
};

export default Footer;