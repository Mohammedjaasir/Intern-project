import React, { useEffect, useState } from 'react';
import { ArrowRight, Sparkles, Zap, Target, Code, Rocket, Star, Crown, Diamond, Gem, Globe, Shield, Award, Layers, Cpu, Database } from 'lucide-react';

interface HeroProps {
  onEnrollClick: () => void;
}

const Hero: React.FC<HeroProps> = ({ onEnrollClick }) => {
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isVisible, setIsVisible] = useState(false);
  const [scrollY, setScrollY] = useState(0);

  useEffect(() => {
    setIsVisible(true);
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };
    const handleScroll = () => setScrollY(window.scrollY);
    
    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('scroll', handleScroll);
    
    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <section className="pt-20 pb-16 px-4 relative overflow-hidden min-h-screen flex items-center">
      {/* WORLD-CLASS DYNAMIC BACKGROUND SYSTEM */}
      
      {/* Ultra Dynamic Mouse-Following Gradient */}
      <div 
        className="absolute w-[1000px] h-[1000px] bg-gradient-to-r from-indigo-400/25 via-violet-500/25 via-fuchsia-500/25 via-rose-400/25 to-indigo-400/25 rounded-full blur-3xl transition-all duration-500 ease-out pointer-events-none animate-pulse-slow"
        style={{
          left: mousePosition.x - 500,
          top: mousePosition.y - 500,
          transform: `scale(${1 + scrollY * 0.001})`,
        }}
      />

      {/* Premium Hero Background with Parallax */}
      <div className="absolute inset-0 z-0" style={{ transform: `translateY(${scrollY * 0.5}px)` }}>
        <img 
          src="https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop"
          alt="Coding workspace"
          className="w-full h-full object-cover opacity-20"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-slate-950/90 via-indigo-950/90 via-violet-950/90 via-fuchsia-950/90 to-slate-950/90"></div>
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950/50 via-transparent to-slate-950/30"></div>
      </div>

      {/* ULTRA ENHANCED ANIMATED BACKGROUND ELEMENTS */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Massive Gradient Orbs with Parallax */}
        <div 
          className="absolute top-1/4 left-1/4 w-[600px] h-[600px] bg-gradient-to-r from-indigo-400/12 via-violet-500/12 via-fuchsia-600/12 to-rose-500/12 rounded-full blur-3xl animate-pulse-slow"
          style={{ transform: `translate(${scrollY * 0.3}px, ${scrollY * 0.2}px)` }}
        ></div>
        <div 
          className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-gradient-to-r from-fuchsia-500/12 via-rose-500/12 via-amber-500/12 to-orange-500/12 rounded-full blur-3xl animate-pulse-slow delay-1000"
          style={{ transform: `translate(${-scrollY * 0.2}px, ${-scrollY * 0.3}px)` }}
        ></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-r from-violet-500/8 via-fuchsia-500/8 via-rose-500/8 via-amber-500/8 to-indigo-500/8 rounded-full blur-3xl animate-ping-slow"></div>
        
        {/* Premium Geometric Patterns */}
        <div className="absolute top-20 right-20 w-64 h-64 border-4 border-gradient-rainbow rounded-full animate-spin-ultra-slow opacity-30"></div>
        <div className="absolute bottom-20 left-20 w-48 h-48 border-4 border-gradient-rainbow rounded-full animate-spin-reverse-slow opacity-20"></div>
        <div className="absolute top-1/3 right-1/3 w-32 h-32 border-2 border-gradient-rainbow rounded-lg rotate-45 animate-float-geometric opacity-25"></div>
        
        {/* Enhanced Floating Code Elements */}
        {[...Array(25)].map((_, i) => (
          <div
            key={i}
            className="absolute text-lg font-mono animate-float-code opacity-40 font-bold"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${4 + Math.random() * 3}s`,
              color: ['#6366F1', '#8B5CF6', '#D946EF', '#F97316', '#10B981', '#F59E0B', '#EC4899', '#06B6D4'][Math.floor(Math.random() * 8)],
              fontSize: `${12 + Math.random() * 12}px`
            }}
          >
            {['</>', '{}', '[]', '()', '&&', '||', '=>', '++', 'const', 'let', 'function', 'class', 'import', 'export', 'async', 'await', 'React', 'Node.js'][Math.floor(Math.random() * 18)]}
          </div>
        ))}

        {/* Premium Floating Geometric Shapes */}
        {[...Array(15)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-float-geometric-premium opacity-30"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${6 + Math.random() * 4}s`
            }}
          >
            <div className={`w-6 h-6 ${['bg-gradient-to-r from-indigo-400 to-violet-500', 'bg-gradient-to-r from-fuchsia-500 to-rose-500', 'bg-gradient-to-r from-amber-400 to-orange-500', 'bg-gradient-to-r from-emerald-400 to-teal-500', 'bg-gradient-to-r from-violet-400 to-fuchsia-500'][Math.floor(Math.random() * 5)]} ${['rounded-full', 'rounded-lg', 'transform rotate-45', 'rounded-xl'][Math.floor(Math.random() * 4)]} blur-sm shadow-lg`}></div>
          </div>
        ))}

        {/* Tech Icons Floating */}
        {[...Array(10)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-float-tech opacity-20"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 4}s`,
              animationDuration: `${8 + Math.random() * 4}s`
            }}
          >
            {[
              <Globe className="w-6 h-6 text-indigo-400" />,
              <Shield className="w-6 h-6 text-violet-400" />,
              <Layers className="w-6 h-6 text-fuchsia-400" />,
              <Cpu className="w-6 h-6 text-rose-400" />,
              <Database className="w-6 h-6 text-emerald-400" />
            ][Math.floor(Math.random() * 5)]}
          </div>
        ))}
      </div>

      <div className="container mx-auto relative z-10 max-w-7xl">
        <div className="text-center">
          {/* COMPACT FLOATING ICONS SYSTEM */}
          <div className={`flex justify-center items-center space-x-4 mb-12 transition-all duration-3000 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
            {[
              { Icon: Sparkles, color: 'from-indigo-400/30 via-violet-500/30 to-fuchsia-600/30', border: 'border-indigo-400/50', glow: 'shadow-indigo-500/40' },
              { Icon: Crown, color: 'from-violet-400/30 via-fuchsia-500/30 to-rose-600/30', border: 'border-violet-400/50', glow: 'shadow-violet-500/40' },
              { Icon: Diamond, color: 'from-fuchsia-400/30 via-rose-500/30 to-amber-500/30', border: 'border-fuchsia-400/50', glow: 'shadow-fuchsia-500/40' },
              { Icon: Code, color: 'from-emerald-400/30 via-teal-500/30 to-indigo-500/30', border: 'border-emerald-400/50', glow: 'shadow-emerald-500/40' },
              { Icon: Rocket, color: 'from-rose-400/30 via-amber-500/30 to-orange-500/30', border: 'border-rose-400/50', glow: 'shadow-rose-500/40' },
              { Icon: Gem, color: 'from-amber-400/30 via-orange-500/30 to-red-500/30', border: 'border-amber-400/50', glow: 'shadow-amber-500/40' }
            ].map(({ Icon, color, border, glow }, index) => (
              <div 
                key={index}
                className={`p-4 bg-gradient-to-r ${color} rounded-xl backdrop-blur-xl border-2 ${border} animate-bounce hover:scale-125 transition-all duration-700 ${glow} shadow-lg group cursor-pointer`}
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <Icon className="w-8 h-8 text-white group-hover:text-white transition-colors duration-500 filter drop-shadow-lg" />
                <div className="absolute inset-0 bg-white/10 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              </div>
            ))}
          </div>

          {/* OPTIMIZED MAIN HEADING - Perfect Size & Compelling Text */}
          <div className={`mb-16 transition-all duration-3000 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
            {/* Complete Heading in Responsive Blocks - OPTIMIZED SIZE */}
            <div className="space-y-4">
              {/* Line 1: "Unlock Your" - PERFECT SIZE */}
              <div className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl font-black text-white leading-tight">
                <span className="inline-block animate-fadeInUp-premium">Unlock</span>{' '}
                <span className="inline-block animate-fadeInUp-premium delay-200">Your</span>
              </div>
              
              {/* Line 2: "Tech Potential" - PERFECT SIZE */}
              <div className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl font-black leading-tight">
                <span className="bg-gradient-to-r from-indigo-300 via-violet-400 via-fuchsia-400 via-rose-400 via-amber-400 to-orange-400 bg-clip-text text-transparent animate-rainbow-gradient-premium">
                  <span className="inline-block animate-fadeInUp-premium delay-400">Tech</span>{' '}
                  <span className="inline-block animate-fadeInUp-premium delay-600">Potential</span>
                </span>
              </div>
              
              {/* Line 3: "with" - PERFECT SIZE */}
              <div className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl font-black text-white leading-tight">
                <span className="inline-block animate-fadeInUp-premium delay-800">with</span>
              </div>
              
              {/* Line 4: "CodeBind" - PERFECT SIZE */}
              <div className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl font-black leading-tight">
                <span className="bg-gradient-to-r from-emerald-300 via-indigo-400 via-violet-400 via-fuchsia-400 to-rose-400 bg-clip-text text-transparent animate-rainbow-gradient-premium delay-300">
                  <span className="inline-block animate-fadeInUp-premium delay-1000">CodeBind</span>
                </span>
              </div>
              
              {/* Line 5: "Technologies" - PERFECT SIZE */}
              <div className="text-5xl sm:text-6xl md:text-7xl lg:text-8xl xl:text-9xl font-black leading-tight">
                <span className="bg-gradient-to-r from-violet-300 via-fuchsia-400 via-rose-400 via-amber-400 to-emerald-400 bg-clip-text text-transparent animate-rainbow-gradient-premium delay-600">
                  <span className="inline-block animate-fadeInUp-premium delay-1200">Technologies</span>
                </span>
              </div>
            </div>
          </div>

          {/* COMPELLING SUBTITLE */}
          <p className={`text-xl sm:text-2xl md:text-3xl lg:text-4xl text-gray-100 mb-16 max-w-6xl mx-auto leading-relaxed transition-all duration-3000 delay-500 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'} font-light px-4`}>
            Join the <span className="text-transparent bg-gradient-to-r from-indigo-300 to-violet-400 bg-clip-text font-bold animate-pulse-premium">elite community</span> of 
            <span className="text-transparent bg-gradient-to-r from-violet-300 to-fuchsia-400 bg-clip-text font-bold animate-pulse-premium"> future tech leaders</span>. 
            Transform from <span className="text-transparent bg-gradient-to-r from-emerald-300 to-teal-400 bg-clip-text font-bold animate-pulse-premium">coding enthusiast</span> to 
            <span className="text-transparent bg-gradient-to-r from-rose-300 to-amber-400 bg-clip-text font-bold animate-pulse-premium"> industry expert</span> with 
            <span className="text-transparent bg-gradient-to-r from-amber-300 to-orange-400 bg-clip-text font-bold animate-pulse-premium">guaranteed career success</span>.
          </p>

          {/* IMPRESSIVE STATS WITH PREMIUM IMAGES */}
          <div className={`flex flex-wrap justify-center items-center gap-12 mb-16 transition-all duration-3000 delay-700 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
            {[
              {
                number: '1000+',
                label: 'Success Stories',
                image: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=120&h=120&fit=crop',
                gradient: 'from-indigo-300 via-violet-400 to-fuchsia-500',
                icons: [Star, Crown, Diamond]
              },
              {
                number: '100+',
                label: 'Global Partners',
                image: 'https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=120&h=120&fit=crop',
                gradient: 'from-fuchsia-300 via-rose-400 to-amber-500',
                icons: [Diamond, Gem, Award]
              },
              {
                number: '98%',
                label: 'Placement Rate',
                image: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=120&h=120&fit=crop',
                gradient: 'from-emerald-300 via-teal-400 to-indigo-500',
                icons: [Sparkles, Target, Rocket]
              }
            ].map((stat, index) => (
              <div key={index} className="text-center group hover:scale-110 transition-all duration-700 cursor-pointer">
                <div className="relative mb-6">
                  {/* Enhanced Glow Effect */}
                  <div className={`absolute inset-0 bg-gradient-to-r ${stat.gradient} rounded-full blur-xl opacity-50 animate-pulse-premium group-hover:opacity-80 transition-opacity duration-700`}></div>
                  
                  {/* Main Image */}
                  <img 
                    src={stat.image}
                    alt={stat.label}
                    className="w-20 h-20 rounded-full mx-auto border-4 border-gradient-to-r shadow-xl relative z-10 group-hover:scale-110 transition-transform duration-700"
                    style={{ borderImage: `linear-gradient(45deg, ${stat.gradient.replace('from-', '').replace('via-', ', ').replace('to-', ', ')}) 1` }}
                  />
                  
                  {/* Floating Icons */}
                  {stat.icons.map((Icon, iconIndex) => (
                    <div
                      key={iconIndex}
                      className={`absolute w-6 h-6 bg-gradient-to-r ${stat.gradient} rounded-full flex items-center justify-center animate-bounce shadow-lg`}
                      style={{
                        top: iconIndex === 0 ? '-8px' : iconIndex === 1 ? '50%' : 'auto',
                        bottom: iconIndex === 2 ? '-6px' : 'auto',
                        right: iconIndex === 0 ? '-8px' : iconIndex === 1 ? '-12px' : 'auto',
                        left: iconIndex === 2 ? '-6px' : 'auto',
                        animationDelay: `${iconIndex * 0.3}s`
                      }}
                    >
                      <Icon className="w-3 h-3 text-white" />
                    </div>
                  ))}
                </div>
                
                <div className={`text-4xl md:text-5xl lg:text-6xl font-black bg-gradient-to-r ${stat.gradient} bg-clip-text text-transparent animate-number-count-premium mb-2`}>
                  {stat.number}
                </div>
                <div className="text-gray-200 font-semibold text-lg group-hover:text-white transition-colors duration-500">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>

          {/* COMPELLING CTA BUTTONS */}
          <div className={`flex flex-col sm:flex-row gap-6 justify-center items-center transition-all duration-3000 delay-1000 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
            <button
              onClick={onEnrollClick}
              className="group relative px-12 py-5 bg-gradient-to-r from-indigo-400 via-violet-500 via-fuchsia-600 via-rose-500 via-amber-500 to-orange-500 text-white rounded-2xl font-black text-2xl hover:from-indigo-500 hover:via-violet-600 hover:via-fuchsia-700 hover:via-rose-600 hover:via-amber-600 hover:to-orange-600 transform hover:scale-110 transition-all duration-1000 shadow-xl hover:shadow-indigo-500/40 flex items-center space-x-4 overflow-hidden animate-rainbow-border-premium backdrop-blur-xl"
            >
              {/* Enhanced Shimmer Effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-white/40 via-transparent via-white/40 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-1000 animate-shimmer-premium"></div>
              
              {/* Premium Glow Layers */}
              <div className="absolute inset-0 bg-gradient-to-r from-indigo-400/40 via-violet-600/40 via-fuchsia-600/40 to-rose-600/40 blur-xl group-hover:blur-2xl transition-all duration-1000"></div>
              <div className="absolute -inset-2 bg-gradient-to-r from-indigo-400/20 via-violet-600/20 via-fuchsia-600/20 to-rose-600/20 blur-2xl group-hover:blur-3xl transition-all duration-1000"></div>
              
              <Rocket className="w-8 h-8 group-hover:animate-bounce relative z-10 group-hover:rotate-12 transition-transform duration-700" />
              <span className="relative z-10 tracking-wide">Start Your Journey</span>
              <ArrowRight className="w-8 h-8 group-hover:translate-x-2 group-hover:scale-125 transition-all duration-1000 relative z-10" />
            </button>
            
            <button className="group px-12 py-5 bg-gradient-to-r from-white/20 via-white/15 to-white/20 backdrop-blur-2xl border-4 border-gradient-to-r from-indigo-400 via-violet-500 via-fuchsia-500 to-rose-500 text-white rounded-2xl font-black text-2xl hover:bg-gradient-to-r hover:from-white/30 hover:via-white/25 hover:to-white/30 hover:border-white/60 transition-all duration-1000 shadow-xl hover:shadow-violet-500/40 hover:scale-110 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-indigo-400/10 via-violet-500/10 via-fuchsia-500/10 to-rose-500/10 opacity-0 group-hover:opacity-100 transition-opacity duration-1000"></div>
              <span className="bg-gradient-to-r from-white via-indigo-200 via-violet-200 via-fuchsia-200 to-rose-200 bg-clip-text text-transparent group-hover:from-indigo-300 group-hover:via-violet-300 group-hover:via-fuchsia-300 group-hover:to-rose-300 transition-all duration-1000 relative z-10 tracking-wide">
                Explore Programs
              </span>
            </button>
          </div>

          {/* SCROLL INDICATOR */}
          <div className={`mt-20 relative transition-all duration-3000 delay-1200 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
            <div className="inline-block animate-bounce-premium">
              <div className="w-8 h-16 border-4 border-gradient-to-b from-indigo-400 via-violet-500 via-fuchsia-500 to-rose-500 rounded-full relative overflow-hidden shadow-xl shadow-violet-500/40 backdrop-blur-sm">
                <div className="w-2 h-6 bg-gradient-to-b from-indigo-400 via-violet-500 via-fuchsia-500 to-rose-500 rounded-full mx-auto mt-2 animate-scroll-indicator-premium"></div>
              </div>
            </div>
            <p className="text-gray-200 mt-6 text-xl font-bold animate-pulse-premium bg-gradient-to-r from-indigo-300 via-violet-300 via-fuchsia-300 to-rose-300 bg-clip-text text-transparent">
              ✨ Your Success Story Starts Here ✨
            </p>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes fadeInUp-premium {
          from {
            opacity: 0;
            transform: translateY(60px) scale(0.9);
          }
          to {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }
        
        @keyframes rainbow-gradient-premium {
          0%, 100% {
            background-size: 600% 600%;
            background-position: 0% 50%;
          }
          25% {
            background-position: 100% 50%;
          }
          50% {
            background-position: 100% 100%;
          }
          75% {
            background-position: 0% 100%;
          }
        }
        
        @keyframes float-code {
          0%, 100% {
            transform: translateY(0px) rotate(0deg) scale(1);
            opacity: 0.4;
          }
          25% {
            transform: translateY(-20px) rotate(90deg) scale(1.1);
            opacity: 0.7;
          }
        50% {
            transform: translateY(-40px) rotate(180deg) scale(1.2);
            opacity: 1;
          }
          75% {
            transform: translateY(-20px) rotate(270deg) scale(1.1);
            opacity: 0.7;
          }
        }
        
        @keyframes float-geometric-premium {
          0%, 100% {
            transform: translateY(0px) rotate(0deg) scale(1);
          }
          33% {
            transform: translateY(-30px) rotate(120deg) scale(1.3);
          }
          66% {
            transform: translateY(-15px) rotate(240deg) scale(0.7);
          }
        }
        
        @keyframes float-tech {
          0%, 100% {
            transform: translateY(0px) rotate(0deg) scale(1);
            opacity: 0.2;
          }
          50% {
            transform: translateY(-50px) rotate(180deg) scale(1.5);
            opacity: 0.6;
          }
        }
        
        @keyframes pulse-slow {
          0%, 100% {
            opacity: 0.8;
            transform: scale(1);
          }
          50% {
            opacity: 1;
            transform: scale(1.05);
          }
        }
        
        @keyframes pulse-premium {
          0%, 100% {
            opacity: 0.8;
            transform: scale(1);
          }
          50% {
            opacity: 1;
            transform: scale(1.1);
          }
        }
        
        @keyframes ping-slow {
          0% {
            transform: scale(1);
            opacity: 1;
          }
          75%, 100% {
            transform: scale(2);
            opacity: 0;
          }
        }
        
        @keyframes spin-ultra-slow {
          from {
            transform: rotate(0deg);
          }
          to {
            transform: rotate(360deg);
          }
        }
        
        @keyframes spin-reverse-slow {
          from {
            transform: rotate(360deg);
          }
          to {
            transform: rotate(0deg);
          }
        }
        
        @keyframes bounce-premium {
          0%, 100% {
            transform: translateY(0) scale(1);
          }
          50% {
            transform: translateY(-30px) scale(1.05);
          }
        }
        
        @keyframes shimmer-premium {
          0% {
            transform: translateX(-100%) skewX(-15deg);
          }
          100% {
            transform: translateX(200%) skewX(-15deg);
          }
        }
        
        @keyframes number-count-premium {
          0% {
            opacity: 0;
            transform: scale(0.3) rotate(-10deg);
          }
          50% {
            opacity: 0.8;
            transform: scale(1.3) rotate(5deg);
          }
          100% {
            opacity: 1;
            transform: scale(1) rotate(0deg);
          }
        }
        
        @keyframes scroll-indicator-premium {
          0% {
            transform: translateY(-100%);
            opacity: 0;
          }
          50% {
            opacity: 1;
          }
          100% {
            transform: translateY(300%);
            opacity: 0;
          }
        }
        
        @keyframes rainbow-border-premium {
          0%, 100% {
            border-image: linear-gradient(45deg, #6366F1, #8B5CF6, #D946EF, #F97316, #10B981) 1;
          }
          20% {
            border-image: linear-gradient(45deg, #8B5CF6, #D946EF, #F97316, #10B981, #6366F1) 1;
          }
          40% {
            border-image: linear-gradient(45deg, #D946EF, #F97316, #10B981, #6366F1, #8B5CF6) 1;
          }
          60% {
            border-image: linear-gradient(45deg, #F97316, #10B981, #6366F1, #8B5CF6, #D946EF) 1;
          }
          80% {
            border-image: linear-gradient(45deg, #10B981, #6366F1, #8B5CF6, #D946EF, #F97316) 1;
          }
        }
        
        .animate-fadeInUp-premium {
          animation: fadeInUp-premium 1.5s ease-out forwards;
        }
        
        .animate-rainbow-gradient-premium {
          animation: rainbow-gradient-premium 5s ease infinite;
        }
        
        .animate-float-code {
          animation: float-code 10s ease-in-out infinite;
        }
        
        .animate-float-geometric-premium {
          animation: float-geometric-premium 12s ease-in-out infinite;
        }
        
        .animate-float-tech {
          animation: float-tech 15s ease-in-out infinite;
        }
        
        .animate-pulse-slow {
          animation: pulse-slow 4s ease-in-out infinite;
        }
        
        .animate-pulse-premium {
          animation: pulse-premium 3s ease-in-out infinite;
        }
        
        .animate-ping-slow {
          animation: ping-slow 3s cubic-bezier(0, 0, 0.2, 1) infinite;
        }
        
        .animate-spin-ultra-slow {
          animation: spin-ultra-slow 30s linear infinite;
        }
        
        .animate-spin-reverse-slow {
          animation: spin-reverse-slow 25s linear infinite;
        }
        
        .animate-bounce-premium {
          animation: bounce-premium 4s ease-in-out infinite;
        }
        
        .animate-shimmer-premium {
          animation: shimmer-premium 4s ease-in-out infinite;
        }
        
        .animate-number-count-premium {
          animation: number-count-premium 2.5s ease-out forwards;
        }
        
        .animate-scroll-indicator-premium {
          animation: scroll-indicator-premium 3s ease-in-out infinite;
        }
        
        .animate-rainbow-border-premium {
          animation: rainbow-border-premium 4s linear infinite;
        }
        
        .delay-200 { animation-delay: 0.2s; }
        .delay-300 { animation-delay: 0.3s; }
        .delay-400 { animation-delay: 0.4s; }
        .delay-500 { animation-delay: 0.5s; }
        .delay-600 { animation-delay: 0.6s; }
        .delay-700 { animation-delay: 0.7s; }
        .delay-800 { animation-delay: 0.8s; }
        .delay-1000 { animation-delay: 1s; }
        .delay-1200 { animation-delay: 1.2s; }
      `}</style>
    </section>
  );
};

export default Hero;