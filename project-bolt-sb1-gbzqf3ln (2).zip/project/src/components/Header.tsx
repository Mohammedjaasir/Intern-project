import React, { useEffect, useState } from 'react';
import { Code2, Menu, X, Sparkles, Star, Zap, Crown, Diamond, Gem, Rocket, Target, Globe, Shield, Award } from 'lucide-react';

const Header: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);
    };
    
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };
    
    window.addEventListener('scroll', handleScroll);
    window.addEventListener('mousemove', handleMouseMove);
    
    return () => {
      window.removeEventListener('scroll', handleScroll);
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-1000 ${scrolled ? 'bg-slate-950/98 backdrop-blur-3xl border-b-2 border-gradient-to-r from-indigo-400 via-violet-500 via-fuchsia-500 to-rose-400 shadow-2xl shadow-violet-500/25' : 'bg-gradient-to-r from-slate-950/80 via-indigo-950/80 via-violet-950/80 to-slate-950/80 backdrop-blur-2xl border-b border-white/30'}`}>
      {/* Ultra Premium Background Layers */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Hero Background Image with Multiple Layers */}
        <div className="absolute inset-0">
          <img 
            src="https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=1920&h=200&fit=crop"
            alt="Header background"
            className="w-full h-full object-cover opacity-20"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-slate-950/95 via-indigo-950/95 via-violet-950/95 to-slate-950/95"></div>
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-slate-950/20 to-slate-950/40"></div>
        </div>

        {/* Animated Mesh Gradient */}
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/10 via-violet-500/10 via-fuchsia-500/10 to-rose-500/10 animate-mesh-gradient"></div>
      </div>

      {/* Ultra Dynamic Mouse-Following Gradient */}
      <div 
        className="absolute w-[800px] h-[800px] bg-gradient-to-r from-indigo-400/20 via-violet-500/20 via-fuchsia-500/20 to-rose-400/20 rounded-full blur-3xl transition-all duration-700 ease-out pointer-events-none opacity-80"
        style={{
          left: mousePosition.x - 400,
          top: mousePosition.y - 400,
        }}
      />

      {/* Premium Floating Particles */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(30)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-twinkle-premium"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${2 + Math.random() * 2}s`
            }}
          >
            <div className={`w-2 h-2 ${['bg-gradient-to-r from-indigo-400 to-violet-500', 'bg-gradient-to-r from-fuchsia-500 to-rose-500', 'bg-gradient-to-r from-amber-400 to-orange-500', 'bg-gradient-to-r from-emerald-400 to-teal-500'][Math.floor(Math.random() * 4)]} rounded-full opacity-60 blur-sm`}></div>
          </div>
        ))}
      </div>

      <div className="container mx-auto px-6 py-3 relative z-10">
        <div className="flex items-center justify-between">
          {/* COMPACT LOGO DESIGN */}
          <div className="flex items-center space-x-4 group cursor-pointer">
            <div className="relative">
              {/* Multi-Layer Logo Background */}
              <div className="absolute inset-0 rounded-2xl overflow-hidden opacity-30 group-hover:opacity-50 transition-all duration-1000">
                <img 
                  src="https://images.pexels.com/photos/574071/pexels-photo-574071.jpeg?auto=compress&cs=tinysrgb&w=80&h=80&fit=crop"
                  alt="Logo background"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-indigo-400/90 via-violet-600/90 via-fuchsia-500/90 to-rose-500/90"></div>
                <div className="absolute inset-0 bg-gradient-to-b from-transparent via-slate-950/20 to-slate-950/40"></div>
              </div>

              {/* Compact Logo Container */}
              <div className="relative p-3 bg-gradient-to-r from-indigo-400 via-violet-500 via-fuchsia-600 via-rose-500 to-amber-500 rounded-2xl group-hover:scale-110 transition-all duration-1000 shadow-xl shadow-indigo-500/50 animate-logo-glow backdrop-blur-xl border border-white/20">
                <Code2 className="w-8 h-8 text-white relative z-10 group-hover:rotate-12 transition-transform duration-700" />
                
                {/* Animated Orbital Rings */}
                <div className="absolute inset-0 rounded-2xl border-2 border-gradient-to-r from-indigo-400 via-violet-500 via-fuchsia-500 to-rose-400 opacity-0 group-hover:opacity-100 transition-opacity duration-1000 animate-spin-slow"></div>
                <div className="absolute inset-1 rounded-xl border border-white/30 opacity-0 group-hover:opacity-100 transition-opacity duration-1000 animate-spin-reverse"></div>
              </div>
              
              {/* Compact Achievement Badges */}
              <div className="absolute -top-2 -right-2 w-5 h-5 rounded-full overflow-hidden animate-bounce shadow-xl">
                <img 
                  src="https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=40&h=40&fit=crop"
                  alt="Achievement"
                  className="w-full h-full object-cover opacity-90"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-amber-400/95 via-orange-500/95 to-red-500/95 flex items-center justify-center">
                  <Crown className="w-2 h-2 text-white animate-pulse" />
                </div>
              </div>
              <div className="absolute -bottom-1 -left-1 w-4 h-4 rounded-full overflow-hidden animate-pulse">
                <img 
                  src="https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=30&h=30&fit=crop"
                  alt="Team"
                  className="w-full h-full object-cover opacity-90"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-emerald-400/95 to-teal-500/95 flex items-center justify-center">
                  <Diamond className="w-2 h-2 text-white animate-spin-slow" />
                </div>
              </div>
            </div>
            
            {/* Compact Brand Text */}
            <div className="group-hover:scale-105 transition-transform duration-700">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-white via-indigo-200 via-violet-200 via-fuchsia-200 to-rose-200 bg-clip-text text-transparent animate-text-shimmer">
                CodeBind
              </h1>
              <p className="text-xs bg-gradient-to-r from-indigo-300 via-violet-300 via-fuchsia-300 to-rose-300 bg-clip-text text-transparent font-semibold animate-pulse flex items-center space-x-1">
                <span>Technologies</span>
                <Sparkles className="w-2 h-2 text-indigo-400 animate-spin" />
              </p>
            </div>
            
            {/* Compact Status Indicators */}
            <div className="hidden lg:flex items-center space-x-3 ml-4">
              <div className="flex items-center space-x-2 px-3 py-1 bg-gradient-to-r from-emerald-500/20 to-teal-500/20 rounded-full border border-emerald-400/30 backdrop-blur-sm">
                <div className="w-1 h-1 bg-emerald-400 rounded-full animate-pulse"></div>
                <span className="text-emerald-300 text-xs font-semibold">LIVE</span>
              </div>
              <div className="animate-bounce delay-300">
                <Star className="w-3 h-3 text-amber-400 opacity-80 animate-pulse" />
              </div>
              <div className="animate-bounce delay-700">
                <Award className="w-3 h-3 text-violet-400 opacity-80 animate-pulse" />
              </div>
              <div className="animate-bounce delay-1000">
                <Shield className="w-3 h-3 text-indigo-400 opacity-80 animate-pulse" />
              </div>
            </div>
          </div>

          {/* COMPACT NAVIGATION MENU */}
          <nav className="hidden md:flex items-center space-x-2">
            {[
              { 
                name: 'Home', 
                href: '#home', 
                icon: '🏠', 
                color: 'from-indigo-400 to-violet-500',
                image: 'https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=300&h=150&fit=crop',
                description: 'Welcome to the future of technology',
                badge: 'NEW'
              },
              { 
                name: 'Programs', 
                href: '#programs', 
                icon: '🚀', 
                color: 'from-violet-400 to-fuchsia-500',
                image: 'https://images.pexels.com/photos/574071/pexels-photo-574071.jpeg?auto=compress&cs=tinysrgb&w=300&h=150&fit=crop',
                description: 'Elite learning paths for tomorrow\'s leaders',
                badge: 'HOT'
              },
              { 
                name: 'About', 
                href: '#about', 
                icon: '💎', 
                color: 'from-fuchsia-400 to-rose-500',
                image: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=300&h=150&fit=crop',
                description: 'Our premium story of transformation',
                badge: 'PREMIUM'
              },
              { 
                name: 'Contact', 
                href: '#contact', 
                icon: '⭐', 
                color: 'from-rose-400 to-amber-500',
                image: 'https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=300&h=150&fit=crop',
                description: 'Connect with excellence and innovation',
                badge: 'VIP'
              }
            ].map((item, index) => (
              <div key={item.name} className="group relative">
                <a
                  href={item.href}
                  className="relative px-5 py-2 text-white hover:text-white transition-all duration-700 font-semibold text-base rounded-xl overflow-hidden block backdrop-blur-sm"
                >
                  {/* Multi-Layer Background */}
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-40 transition-all duration-1000">
                    <img 
                      src={item.image} 
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-slate-950/70 to-slate-950/90"></div>
                  </div>

                  {/* Premium Glass Effect */}
                  <div className={`absolute inset-0 bg-gradient-to-r ${item.color} opacity-0 group-hover:opacity-100 transition-all duration-700 rounded-xl backdrop-blur-xl`}></div>
                  <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-all duration-700 rounded-xl backdrop-blur-sm"></div>
                  
                  {/* Animated Border System */}
                  <div className="absolute inset-0 rounded-xl border border-white/20 group-hover:border-white/40 transition-all duration-700"></div>
                  <div className="absolute inset-0 rounded-xl bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 animate-border-flow"></div>
                  
                  {/* Content with Enhanced Typography */}
                  <div className="relative z-10 flex items-center space-x-2">
                    <span className="text-lg group-hover:scale-125 group-hover:animate-bounce transition-all duration-700 filter drop-shadow-lg">
                      {item.icon}
                    </span>
                    <span className="group-hover:text-white transition-colors duration-700 tracking-wide">
                      {item.name}
                    </span>
                    {/* Premium Badge */}
                    <span className={`px-2 py-1 text-xs font-bold bg-gradient-to-r ${item.color} text-white rounded-full opacity-0 group-hover:opacity-100 transition-all duration-700 animate-pulse`}>
                      {item.badge}
                    </span>
                  </div>
                  
                  {/* Enhanced Glow Effects */}
                  <div className={`absolute inset-0 bg-gradient-to-r ${item.color} opacity-0 group-hover:opacity-30 blur-xl transition-all duration-700`}></div>
                  <div className={`absolute -inset-1 bg-gradient-to-r ${item.color} opacity-0 group-hover:opacity-20 blur-2xl transition-all duration-1000`}></div>
                  
                  {/* Premium Indicators */}
                  <div className={`absolute bottom-0 left-1/2 transform -translate-x-1/2 w-0 h-1 bg-gradient-to-r ${item.color} group-hover:w-full transition-all duration-700 rounded-full`}></div>
                  
                  {/* Floating Particles */}
                  <div className="absolute top-1 right-1 opacity-0 group-hover:opacity-100 transition-opacity duration-700">
                    {[...Array(3)].map((_, i) => (
                      <div
                        key={i}
                        className="absolute w-1 h-1 bg-white rounded-full animate-bounce"
                        style={{
                          right: `${i * 4}px`,
                          animationDelay: `${i * 0.1}s`
                        }}
                      />
                    ))}
                  </div>
                </a>

                {/* COMPACT HOVER CARD */}
                <div className="absolute top-full left-1/2 transform -translate-x-1/2 mt-2 w-64 bg-slate-950/95 backdrop-blur-2xl rounded-2xl border border-white/20 shadow-2xl opacity-0 group-hover:opacity-100 transition-all duration-700 pointer-events-none z-50 overflow-hidden">
                  {/* Card Background */}
                  <div className="absolute inset-0">
                    <img 
                      src={item.image} 
                      alt={item.name}
                      className="w-full h-full object-cover opacity-20"
                    />
                    <div className="absolute inset-0 bg-gradient-to-br from-slate-950/90 via-slate-950/95 to-slate-950/90"></div>
                  </div>
                  
                  <div className="relative z-10 p-4">
                    {/* Card Header */}
                    <div className="relative h-16 rounded-xl overflow-hidden mb-3">
                      <img 
                        src={item.image} 
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                      <div className={`absolute inset-0 bg-gradient-to-r ${item.color} opacity-90`}></div>
                      <div className="absolute inset-0 flex items-center justify-center">
                        <span className="text-2xl filter drop-shadow-lg">{item.icon}</span>
                      </div>
                      {/* Premium Badge */}
                      <div className="absolute top-1 right-1 px-2 py-1 bg-slate-950/50 backdrop-blur-sm rounded-full">
                        <span className="text-xs font-bold text-white">{item.badge}</span>
                      </div>
                    </div>
                    
                    {/* Card Content */}
                    <h4 className={`text-white font-bold text-lg mb-2 bg-gradient-to-r ${item.color} bg-clip-text text-transparent`}>
                      {item.name}
                    </h4>
                    <p className="text-gray-300 text-sm leading-relaxed mb-3">
                      {item.description}
                    </p>
                    
                    {/* Card Footer */}
                    <div className="flex items-center justify-between">
                      <div className="flex space-x-1">
                        {[...Array(3)].map((_, i) => (
                          <div key={i} className={`w-1 h-1 bg-gradient-to-r ${item.color} rounded-full animate-pulse`} style={{ animationDelay: `${i * 0.2}s` }}></div>
                        ))}
                      </div>
                      <Globe className="w-3 h-3 text-gray-400 animate-spin-slow" />
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </nav>

          {/* COMPACT MOBILE MENU BUTTON */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden relative p-3 text-white hover:text-white transition-all duration-700 hover:bg-gradient-to-r hover:from-indigo-500/20 hover:to-violet-500/20 rounded-2xl group overflow-hidden backdrop-blur-sm border border-white/20 hover:border-white/40"
          >
            {/* Background Layers */}
            <div className="absolute inset-0 opacity-0 group-hover:opacity-30 transition-opacity duration-700 rounded-2xl overflow-hidden">
              <img 
                src="https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=80&h=80&fit=crop"
                alt="Menu background"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/90 to-violet-500/90"></div>
            </div>

            <div className="absolute inset-0 bg-gradient-to-r from-indigo-400/20 via-violet-500/20 to-fuchsia-500/20 opacity-0 group-hover:opacity-100 transition-opacity duration-700 rounded-2xl"></div>
            
            <div className="relative z-10">
              {isMenuOpen ? (
                <X className="w-6 h-6 group-hover:rotate-180 group-hover:scale-125 transition-all duration-700" />
              ) : (
                <Menu className="w-6 h-6 group-hover:scale-125 transition-all duration-700" />
              )}
            </div>
            
            <div className="absolute inset-0 bg-gradient-to-r from-indigo-400/30 to-violet-500/30 opacity-0 group-hover:opacity-100 blur-xl transition-all duration-700"></div>
          </button>
        </div>

        {/* COMPACT MOBILE NAVIGATION */}
        {isMenuOpen && (
          <nav className="md:hidden mt-6 pb-6 border-t-2 border-gradient-to-r from-indigo-400 via-violet-500 to-fuchsia-500 animate-slideDown backdrop-blur-2xl rounded-2xl overflow-hidden">
            {/* Mobile Menu Background */}
            <div className="absolute inset-0 mt-6 rounded-2xl overflow-hidden opacity-15">
              <img 
                src="https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=800&h=400&fit=crop"
                alt="Mobile menu background"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-br from-slate-950/98 via-indigo-950/98 to-slate-950/98"></div>
            </div>

            <div className="flex flex-col space-y-2 pt-6 relative z-10">
              {[
                { 
                  name: 'Home', 
                  href: '#home', 
                  icon: '🏠', 
                  color: 'from-indigo-400 to-violet-500', 
                  description: 'Welcome to CodeBind - Where innovation meets limitless opportunity',
                  image: 'https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=400&h=200&fit=crop',
                  stats: '1000+ Students'
                },
                { 
                  name: 'Programs', 
                  href: '#programs', 
                  icon: '🚀', 
                  color: 'from-violet-400 to-fuchsia-500', 
                  description: 'Elite learning paths designed for future tech leaders and innovators',
                  image: 'https://images.pexels.com/photos/574071/pexels-photo-574071.jpeg?auto=compress&cs=tinysrgb&w=400&h=200&fit=crop',
                  stats: '6 Specializations'
                },
                { 
                  name: 'About', 
                  href: '#about', 
                  icon: '💎', 
                  color: 'from-fuchsia-400 to-rose-500', 
                  description: 'Our premium story of transforming careers and shaping futures',
                  image: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=400&h=200&fit=crop',
                  stats: '98% Success Rate'
                },
                { 
                  name: 'Contact', 
                  href: '#contact', 
                  icon: '⭐', 
                  color: 'from-rose-400 to-amber-500', 
                  description: 'Connect with excellence and start your extraordinary journey today',
                  image: 'https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=400&h=200&fit=crop',
                  stats: '24/7 Support'
                }
              ].map((item, index) => (
                <a
                  key={item.name}
                  href={item.href}
                  className="group relative p-4 text-white hover:text-white transition-all duration-700 rounded-2xl overflow-hidden backdrop-blur-sm border border-white/10 hover:border-white/30"
                  onClick={() => setIsMenuOpen(false)}
                >
                  {/* Enhanced Background */}
                  <div className="absolute inset-0 opacity-0 group-hover:opacity-50 transition-opacity duration-1000 rounded-2xl overflow-hidden">
                    <img 
                      src={item.image} 
                      alt={item.name}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-r from-slate-950/80 to-slate-950/95"></div>
                  </div>

                  <div className={`absolute inset-0 bg-gradient-to-r ${item.color} opacity-0 group-hover:opacity-100 transition-all duration-700 rounded-2xl`}></div>
                  
                  <div className="relative z-10 flex items-center space-x-4">
                    <div className="relative">
                      {/* Enhanced Icon Background */}
                      <div className="absolute inset-0 rounded-xl overflow-hidden opacity-40 group-hover:opacity-70 transition-opacity duration-700">
                        <img 
                          src={item.image} 
                          alt={item.name}
                          className="w-full h-full object-cover"
                        />
                        <div className={`absolute inset-0 bg-gradient-to-r ${item.color} opacity-90`}></div>
                      </div>
                      <div className="relative p-2 bg-gradient-to-r from-white/10 to-white/5 rounded-xl group-hover:scale-125 group-hover:rotate-12 transition-all duration-700 backdrop-blur-sm border border-white/20">
                        <span className="text-2xl relative z-10 filter drop-shadow-lg">{item.icon}</span>
                      </div>
                    </div>
                    
                    <div className="flex-1">
                      <div className="flex items-center space-x-2 mb-1">
                        <div className="text-lg font-bold group-hover:text-white transition-colors duration-700">
                          {item.name}
                        </div>
                        <div className={`px-2 py-1 text-xs font-bold bg-gradient-to-r ${item.color} text-white rounded-full opacity-80 group-hover:opacity-100 transition-opacity duration-700`}>
                          {item.stats}
                        </div>
                      </div>
                      <div className="text-sm text-gray-300 group-hover:text-gray-100 transition-colors duration-700 leading-relaxed">
                        {item.description}
                      </div>
                    </div>
                    
                    <div className="flex flex-col space-y-1">
                      {[...Array(3)].map((_, i) => (
                        <div key={i} className={`w-1 h-1 bg-gradient-to-r ${item.color} rounded-full opacity-0 group-hover:opacity-100 transition-opacity duration-${300 + i * 200}`}></div>
                      ))}
                    </div>
                  </div>
                  
                  <div className={`absolute inset-0 bg-gradient-to-r ${item.color} opacity-0 group-hover:opacity-20 blur-xl transition-all duration-700`}></div>
                  
                  {/* Enhanced Floating Particles */}
                  <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity duration-700">
                    {[...Array(4)].map((_, i) => (
                      <div
                        key={i}
                        className="absolute w-1 h-1 bg-white rounded-full animate-bounce"
                        style={{
                          right: `${(i % 2) * 6}px`,
                          top: `${Math.floor(i / 2) * 6}px`,
                          animationDelay: `${i * 0.1}s`
                        }}
                      />
                    ))}
                  </div>
                </a>
              ))}
            </div>
            
            {/* Compact Mobile Footer */}
            <div className="mt-6 pt-4 border-t border-white/20 text-center relative">
              <div className="absolute inset-0 rounded-xl overflow-hidden opacity-30">
                <img 
                  src="https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=400&h=150&fit=crop"
                  alt="Footer background"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-indigo-500/90 via-violet-500/90 to-fuchsia-500/90"></div>
              </div>

              <p className="text-gray-200 text-base mb-4 relative z-10 font-semibold">
                🌟 <span className="bg-gradient-to-r from-indigo-300 via-violet-300 to-fuchsia-300 bg-clip-text text-transparent font-bold">Shape Your Future with Premium Excellence</span> 🌟
              </p>
              <div className="flex justify-center space-x-4 relative z-10">
                {[
                  { Icon: Rocket, image: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=40&h=40&fit=crop', color: 'from-indigo-400 to-violet-500' },
                  { Icon: Target, image: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=40&h=40&fit=crop', color: 'from-violet-400 to-fuchsia-500' },
                  { Icon: Crown, image: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=40&h=40&fit=crop', color: 'from-fuchsia-400 to-rose-500' }
                ].map(({ Icon, image, color }, index) => (
                  <div
                    key={index}
                    className="relative p-2 bg-gradient-to-r from-white/10 to-white/5 rounded-xl animate-bounce overflow-hidden backdrop-blur-sm border border-white/20"
                    style={{ animationDelay: `${index * 0.3}s` }}
                  >
                    <div className="absolute inset-0 opacity-40">
                      <img 
                        src={image} 
                        alt={`Icon ${index}`}
                        className="w-full h-full object-cover"
                      />
                      <div className={`absolute inset-0 bg-gradient-to-r ${color} opacity-90`}></div>
                    </div>
                    <Icon className="w-4 h-4 text-white relative z-10" />
                  </div>
                ))}
              </div>
            </div>
          </nav>
        )}
      </div>

      <style jsx>{`
        @keyframes slideDown {
          from {
            opacity: 0;
            transform: translateY(-40px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        @keyframes twinkle-premium {
          0%, 100% {
            opacity: 0.2;
            transform: scale(1) rotate(0deg);
          }
          50% {
            opacity: 1;
            transform: scale(1.8) rotate(180deg);
          }
        }
        
        @keyframes logo-glow {
          0%, 100% {
            box-shadow: 0 0 30px rgba(99, 102, 241, 0.5), 0 0 60px rgba(139, 92, 246, 0.4), 0 0 90px rgba(217, 70, 239, 0.3);
          }
          25% {
            box-shadow: 0 0 30px rgba(139, 92, 246, 0.5), 0 0 60px rgba(217, 70, 239, 0.4), 0 0 90px rgba(244, 63, 94, 0.3);
          }
          50% {
            box-shadow: 0 0 30px rgba(217, 70, 239, 0.5), 0 0 60px rgba(244, 63, 94, 0.4), 0 0 90px rgba(251, 191, 36, 0.3);
          }
          75% {
            box-shadow: 0 0 30px rgba(244, 63, 94, 0.5), 0 0 60px rgba(251, 191, 36, 0.4), 0 0 90px rgba(99, 102, 241, 0.3);
          }
        }
        
        @keyframes text-shimmer {
          0%, 100% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
        }
        
        @keyframes border-flow {
          0% {
            background-position: 0% 50%;
          }
          100% {
            background-position: 100% 50%;
          }
        }
        
        @keyframes spin-slow {
          from {
            transform: rotate(0deg);
          }
          to {
            transform: rotate(360deg);
          }
        }
        
        @keyframes spin-reverse {
          from {
            transform: rotate(360deg);
          }
          to {
            transform: rotate(0deg);
          }
        }
        
        @keyframes mesh-gradient {
          0%, 100% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
        }
        
        .animate-slideDown {
          animation: slideDown 0.7s ease-out forwards;
        }
        
        .animate-twinkle-premium {
          animation: twinkle-premium 3s ease-in-out infinite;
        }
        
        .animate-logo-glow {
          animation: logo-glow 4s ease-in-out infinite;
        }
        
        .animate-text-shimmer {
          background-size: 200% 200%;
          animation: text-shimmer 4s ease infinite;
        }
        
        .animate-border-flow {
          background-size: 200% 200%;
          animation: border-flow 3s linear infinite;
        }
        
        .animate-spin-slow {
          animation: spin-slow 12s linear infinite;
        }
        
        .animate-spin-reverse {
          animation: spin-reverse 8s linear infinite;
        }
        
        .animate-mesh-gradient {
          background-size: 400% 400%;
          animation: mesh-gradient 6s ease infinite;
        }
      `}</style>
    </header>
  );
};

export default Header;