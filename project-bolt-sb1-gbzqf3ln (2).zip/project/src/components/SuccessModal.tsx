import React, { useEffect, useState } from 'react';
import { CheckCircle, Sparkles, Star, Trophy, ArrowRight, Download, Rocket, Zap, Target, Gift, Crown, Medal } from 'lucide-react';

interface Student {
  id: string;
  name: string;
  email: string;
  phone: string;
  university: string;
  course: string;
  year: string;
  skills: string;
  motivation: string;
  registeredAt: string;
}

interface SuccessModalProps {
  student: Student;
  onClose: () => void;
}

const SuccessModal: React.FC<SuccessModalProps> = ({ student, onClose }) => {
  const [showConfetti, setShowConfetti] = useState(true);
  const [animationPhase, setAnimationPhase] = useState(0);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const timer1 = setTimeout(() => setAnimationPhase(1), 500);
    const timer2 = setTimeout(() => setAnimationPhase(2), 1500);
    const timer3 = setTimeout(() => setAnimationPhase(3), 2500);
    const timer4 = setTimeout(() => setShowConfetti(false), 5000);

    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener('mousemove', handleMouseMove);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearTimeout(timer4);
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  const generateCertificateId = () => {
    return `CB-${new Date().getFullYear()}-${student.id.slice(-6).toUpperCase()}`;
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md overflow-hidden">
      {/* Dynamic Mouse-Following Gradient */}
      <div 
        className="absolute w-96 h-96 bg-gradient-to-r from-green-500/30 via-cyan-500/30 to-purple-500/30 rounded-full blur-3xl transition-all duration-1000 ease-out pointer-events-none"
        style={{
          left: mousePosition.x - 192,
          top: mousePosition.y - 192,
        }}
      />

      {/* Enhanced Confetti Effect */}
      {showConfetti && (
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {/* Confetti Particles */}
          {[...Array(100)].map((_, i) => (
            <div
              key={i}
              className="absolute animate-confetti-fall"
              style={{
                left: `${Math.random() * 100}%`,
                top: `-10%`,
                animationDelay: `${Math.random() * 3}s`,
                animationDuration: `${3 + Math.random() * 2}s`
              }}
            >
              <div className={`w-3 h-3 ${['bg-yellow-400', 'bg-pink-400', 'bg-cyan-400', 'bg-green-400', 'bg-purple-400', 'bg-orange-400'][Math.floor(Math.random() * 6)]} ${['rounded-full', 'rounded-none'][Math.floor(Math.random() * 2)]} opacity-80`} />
            </div>
          ))}
          
          {/* Floating Icons */}
          {[...Array(30)].map((_, i) => (
            <div
              key={i}
              className="absolute animate-float-up"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${4 + Math.random() * 2}s`
              }}
            >
              {[
                <Sparkles className="w-6 h-6 text-yellow-400" />,
                <Star className="w-5 h-5 text-pink-400" />,
                <Trophy className="w-6 h-6 text-orange-400" />,
                <Rocket className="w-5 h-5 text-cyan-400" />,
                <Zap className="w-4 h-4 text-purple-400" />,
                <Target className="w-5 h-5 text-green-400" />
              ][Math.floor(Math.random() * 6)]}
            </div>
          ))}
        </div>
      )}

      {/* Background Image */}
      <div className="absolute inset-0">
        <img 
          src="https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop"
          alt="Success celebration"
          className="w-full h-full object-cover opacity-10"
        />
        <div className="absolute inset-0 bg-gradient-to-br from-green-900/90 via-cyan-900/90 to-purple-900/90"></div>
      </div>

      <div className="w-full max-w-4xl bg-white/10 backdrop-blur-xl rounded-3xl border border-white/20 shadow-2xl overflow-hidden relative">
        {/* Ultra Enhanced Success Header */}
        <div className="text-center p-12 bg-gradient-to-r from-green-500/20 via-cyan-500/20 via-blue-500/20 to-purple-500/20 relative overflow-hidden">
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-20">
            <img 
              src="https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=800&h=400&fit=crop"
              alt="Achievement"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-green-500/30 via-cyan-500/30 to-purple-500/30"></div>
          </div>

          <div className={`relative z-10 transition-all duration-1500 ${animationPhase >= 0 ? 'scale-100 opacity-100' : 'scale-0 opacity-0'}`}>
            <div className="relative inline-block mb-8">
              {/* Main Success Icon */}
              <div className="relative">
                <CheckCircle className="w-32 h-32 text-green-400 mx-auto animate-bounce-slow" />
                <div className="absolute inset-0 bg-green-400/20 rounded-full blur-xl animate-pulse"></div>
              </div>
              
              {/* Floating Achievement Icons */}
              <div className="absolute -top-4 -right-4 animate-bounce delay-300">
                <div className="p-3 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full">
                  <Crown className="w-8 h-8 text-white" />
                </div>
              </div>
              <div className="absolute -bottom-4 -left-4 animate-bounce delay-700">
                <div className="p-3 bg-gradient-to-r from-purple-400 to-pink-500 rounded-full">
                  <Medal className="w-8 h-8 text-white" />
                </div>
              </div>
              <div className="absolute top-1/2 -right-8 animate-bounce delay-1000">
                <div className="p-2 bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full">
                  <Star className="w-6 h-6 text-white" />
                </div>
              </div>
            </div>
          </div>

          <h2 className={`text-6xl md:text-8xl font-bold text-white mb-6 transition-all duration-2000 delay-300 ${animationPhase >= 1 ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'}`}>
            <span className="bg-gradient-to-r from-green-400 via-cyan-400 via-blue-400 to-purple-400 bg-clip-text text-transparent animate-gradient-x">
              🎉 SUCCESS! 🎉
            </span>
          </h2>

          <p className={`text-3xl text-gray-200 mb-4 transition-all duration-2000 delay-500 ${animationPhase >= 1 ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'}`}>
            Welcome to the <span className="text-cyan-400 font-bold">CodeBind Family</span>, {student.name.split(' ')[0]}! 🚀
          </p>

          <p className={`text-xl text-gray-300 transition-all duration-2000 delay-700 ${animationPhase >= 1 ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'}`}>
            Your journey to becoming a <span className="text-purple-400 font-semibold">tech leader</span> starts now!
          </p>
        </div>

        {/* Enhanced Student Details */}
        <div className={`p-10 transition-all duration-2000 delay-1000 ${animationPhase >= 2 ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'}`}>
          {/* Achievement Card */}
          <div className="bg-gradient-to-r from-white/10 via-white/5 to-white/10 rounded-3xl p-8 mb-8 border border-white/20 relative overflow-hidden">
            <div className="absolute inset-0 bg-gradient-to-r from-green-500/5 via-cyan-500/5 to-purple-500/5"></div>
            
            <h3 className="text-3xl font-bold text-white mb-6 flex items-center justify-center">
              <Trophy className="w-8 h-8 text-yellow-400 mr-3 animate-bounce" />
              <span className="bg-gradient-to-r from-yellow-400 to-orange-400 bg-clip-text text-transparent">
                Enrollment Achievement Unlocked!
              </span>
              <Gift className="w-8 h-8 text-pink-400 ml-3 animate-bounce delay-300" />
            </h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 text-center">
              <div className="p-4 bg-white/5 rounded-2xl border border-cyan-400/30 hover:bg-white/10 transition-all duration-300 group">
                <div className="text-cyan-400 font-bold text-lg">Student ID</div>
                <div className="text-white font-semibold text-xl group-hover:text-cyan-300 transition-colors duration-300">
                  {generateCertificateId()}
                </div>
              </div>
              <div className="p-4 bg-white/5 rounded-2xl border border-purple-400/30 hover:bg-white/10 transition-all duration-300 group">
                <div className="text-purple-400 font-bold text-lg">Registration Date</div>
                <div className="text-white font-semibold text-xl group-hover:text-purple-300 transition-colors duration-300">
                  {new Date(student.registeredAt).toLocaleDateString('en-US', {
                    year: 'numeric',
                    month: 'short',
                    day: 'numeric'
                  })}
                </div>
              </div>
              <div className="p-4 bg-white/5 rounded-2xl border border-green-400/30 hover:bg-white/10 transition-all duration-300 group">
                <div className="text-green-400 font-bold text-lg">Program Track</div>
                <div className="text-white font-semibold text-xl group-hover:text-green-300 transition-colors duration-300">
                  Full-Stack Pro
                </div>
              </div>
              <div className="p-4 bg-white/5 rounded-2xl border border-orange-400/30 hover:bg-white/10 transition-all duration-300 group">
                <div className="text-orange-400 font-bold text-lg">Duration</div>
                <div className="text-white font-semibold text-xl group-hover:text-orange-300 transition-colors duration-300">
                  6 Months
                </div>
              </div>
            </div>
          </div>

          {/* Enhanced Next Steps */}
          <div className={`bg-gradient-to-r from-cyan-500/10 via-blue-500/10 via-purple-500/10 to-pink-500/10 rounded-3xl p-8 mb-8 border border-cyan-500/20 transition-all duration-2000 delay-1200 ${animationPhase >= 3 ? 'translate-y-0 opacity-100' : 'translate-y-8 opacity-0'}`}>
            <h4 className="text-3xl font-bold text-white mb-8 text-center">
              <Rocket className="w-8 h-8 text-cyan-400 inline-block mr-3 animate-bounce" />
              Your Success Roadmap
              <Zap className="w-8 h-8 text-purple-400 inline-block ml-3 animate-bounce delay-300" />
            </h4>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[
                {
                  icon: '📧',
                  title: 'Welcome Package',
                  description: 'Check your email for exclusive resources and orientation details',
                  color: 'from-cyan-400 to-blue-500'
                },
                {
                  icon: '💬',
                  title: 'Discord Community',
                  description: 'Join our exclusive community of 1000+ tech enthusiasts',
                  color: 'from-purple-400 to-pink-500'
                },
                {
                  icon: '👨‍🏫',
                  title: 'Mentoring Session',
                  description: 'Schedule your personalized one-on-one career guidance',
                  color: 'from-green-400 to-teal-500'
                },
                {
                  icon: '📊',
                  title: 'Learning Dashboard',
                  description: 'Access your personalized learning path and progress tracker',
                  color: 'from-orange-400 to-red-500'
                }
              ].map((step, index) => (
                <div
                  key={index}
                  className="group p-6 bg-white/5 rounded-2xl border border-white/10 hover:bg-white/10 hover:border-white/20 transition-all duration-500 hover:scale-105 hover:shadow-xl"
                >
                  <div className="flex items-start space-x-4">
                    <div className={`text-4xl p-3 bg-gradient-to-r ${step.color} rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                      {step.icon}
                    </div>
                    <div className="flex-1">
                      <h5 className="text-xl font-bold text-white mb-2 group-hover:text-cyan-300 transition-colors duration-300">
                        {step.title}
                      </h5>
                      <p className="text-gray-300 group-hover:text-gray-200 transition-colors duration-300">
                        {step.description}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Enhanced Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-6 mb-8">
            <button className="group flex-1 py-5 px-8 bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-600 text-white font-bold text-xl rounded-2xl hover:from-cyan-600 hover:via-blue-600 hover:to-purple-700 transition-all duration-500 flex items-center justify-center space-x-3 hover:scale-105 hover:shadow-2xl hover:shadow-cyan-500/25 relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <Download className="w-6 h-6 group-hover:animate-bounce relative z-10" />
              <span className="relative z-10">Download Certificate</span>
              <Star className="w-6 h-6 group-hover:animate-spin relative z-10" />
            </button>
            
            <button
              onClick={onClose}
              className="group flex-1 py-5 px-8 bg-white/10 border-2 border-white/20 text-white font-bold text-xl rounded-2xl hover:bg-white/20 hover:border-white/40 transition-all duration-500 flex items-center justify-center space-x-3 hover:scale-105 hover:shadow-xl"
            >
              <span className="bg-gradient-to-r from-white to-gray-300 bg-clip-text text-transparent group-hover:from-cyan-300 group-hover:to-purple-300 transition-all duration-500">
                Continue Exploring
              </span>
              <ArrowRight className="w-6 h-6 group-hover:translate-x-2 transition-transform duration-500" />
            </button>
          </div>

          {/* Enhanced Contact Info */}
          <div className="text-center p-6 bg-gradient-to-r from-white/5 to-white/10 rounded-2xl border border-white/10">
            <p className="text-gray-300 text-lg mb-2">
              🤝 Questions? Our team is here to help!
            </p>
            <p className="text-gray-400">
              Reach out to us at{' '}
              <a href="mailto:hello@codebind.tech" className="text-cyan-400 hover:text-cyan-300 font-semibold transition-colors duration-300">
                hello@codebind.tech
              </a>
              {' '}or call{' '}
              <a href="tel:+919876543210" className="text-purple-400 hover:text-purple-300 font-semibold transition-colors duration-300">
                +91 98765 43210
              </a>
            </p>
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes confetti-fall {
          0% {
            transform: translateY(-100vh) rotate(0deg);
            opacity: 1;
          }
          100% {
            transform: translateY(100vh) rotate(720deg);
            opacity: 0;
          }
        }
        
        @keyframes float-up {
          0% {
            transform: translateY(0px) rotate(0deg);
            opacity: 0.8;
          }
          50% {
            transform: translateY(-50px) rotate(180deg);
            opacity: 1;
          }
          100% {
            transform: translateY(-100px) rotate(360deg);
            opacity: 0;
          }
        }
        
        @keyframes bounce-slow {
          0%, 100% {
            transform: translateY(0);
          }
          50% {
            transform: translateY(-20px);
          }
        }
        
        @keyframes gradient-x {
          0%, 100% {
            background-size: 200% 200%;
            background-position: left center;
          }
          50% {
            background-size: 200% 200%;
            background-position: right center;
          }
        }
        
        .animate-confetti-fall {
          animation: confetti-fall linear forwards;
        }
        
        .animate-float-up {
          animation: float-up ease-out forwards;
        }
        
        .animate-bounce-slow {
          animation: bounce-slow 2s ease-in-out infinite;
        }
        
        .animate-gradient-x {
          animation: gradient-x 3s ease infinite;
        }
      `}</style>
    </div>
  );
};

export default SuccessModal;