import React, { useEffect, useState } from 'react';
import { BookOpen, Users, Award, Briefcase, Code, Rocket, Star, Zap, Target, Trophy, Globe, Shield, Layers, Cpu, Database, Brain, Smartphone, Cloud } from 'lucide-react';

const Features: React.FC = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
        }
      },
      { threshold: 0.1 }
    );

    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };

    const element = document.getElementById('features-section');
    if (element) observer.observe(element);
    window.addEventListener('mousemove', handleMouseMove);

    return () => {
      observer.disconnect();
      window.removeEventListener('mousemove', handleMouseMove);
    };
  }, []);

  const features = [
    {
      icon: Code,
      title: 'Real-World Projects',
      description: 'Work on live projects with cutting-edge technologies and frameworks used by top companies like Google, Microsoft, Amazon, and Tesla.',
      color: 'from-indigo-500 to-violet-500',
      image: 'https://images.pexels.com/photos/574071/pexels-photo-574071.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      delay: 'delay-100',
      badge: 'LIVE PROJECTS',
      stats: '50+ Projects'
    },
    {
      icon: Users,
      title: 'Expert Mentorship',
      description: 'Learn from industry professionals with 15+ years of experience in leading tech companies, startups, and Fortune 500 companies.',
      color: 'from-violet-500 to-fuchsia-500',
      image: 'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      delay: 'delay-200',
      badge: 'EXPERT MENTORS',
      stats: '50+ Mentors'
    },
    {
      icon: Award,
      title: 'Industry Certification',
      description: 'Earn globally recognized certifications that boost your resume and validate your expertise in the competitive tech industry.',
      color: 'from-fuchsia-500 to-rose-500',
      image: 'https://images.pexels.com/photos/3184360/pexels-photo-3184360.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      delay: 'delay-300',
      badge: 'CERTIFIED',
      stats: '10+ Certificates'
    },
    {
      icon: Briefcase,
      title: 'Job Placement',
      description: 'Get direct placement opportunities with our extensive network of 100+ partner companies across the globe and multiple industries.',
      color: 'from-rose-500 to-amber-500',
      image: 'https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      delay: 'delay-400',
      badge: 'GUARANTEED PLACEMENT',
      stats: '98% Placement'
    },
    {
      icon: BookOpen,
      title: 'Comprehensive Curriculum',
      description: 'Master full-stack development, mobile apps, AI/ML, blockchain, cloud computing, and other cutting-edge technologies.',
      color: 'from-amber-500 to-orange-500',
      image: 'https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      delay: 'delay-500',
      badge: 'COMPREHENSIVE',
      stats: '20+ Technologies'
    },
    {
      icon: Rocket,
      title: 'Career Acceleration',
      description: 'Fast-track your career with personalized guidance, portfolio building, interview preparation, and continuous skill development.',
      color: 'from-emerald-500 to-teal-500',
      image: 'https://images.pexels.com/photos/3184465/pexels-photo-3184465.jpeg?auto=compress&cs=tinysrgb&w=500&h=300&fit=crop',
      delay: 'delay-600',
      badge: 'FAST-TRACK',
      stats: '6 Months'
    }
  ];

  const tracks = [
    {
      name: 'Full-Stack Development',
      icon: Code,
      color: 'from-indigo-400 to-violet-500',
      image: 'https://images.pexels.com/photos/11035380/pexels-photo-11035380.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop',
      technologies: ['React', 'Node.js', 'MongoDB', 'TypeScript', 'Next.js'],
      description: 'Master modern web development with the latest frameworks and tools',
      duration: '6 months',
      level: 'Beginner to Advanced'
    },
    {
      name: 'Mobile App Development',
      icon: Smartphone,
      color: 'from-violet-400 to-fuchsia-500',
      image: 'https://images.pexels.com/photos/147413/twitter-facebook-together-exchange-of-information-147413.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop',
      technologies: ['React Native', 'Flutter', 'iOS', 'Android', 'Kotlin'],
      description: 'Build cross-platform mobile applications for iOS and Android',
      duration: '5 months',
      level: 'Intermediate'
    },
    {
      name: 'AI & Machine Learning',
      icon: Brain,
      color: 'from-fuchsia-400 to-rose-500',
      image: 'https://images.pexels.com/photos/8386440/pexels-photo-8386440.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop',
      technologies: ['Python', 'TensorFlow', 'PyTorch', 'OpenAI', 'Scikit-learn'],
      description: 'Dive into artificial intelligence and machine learning algorithms',
      duration: '8 months',
      level: 'Advanced'
    },
    {
      name: 'DevOps & Cloud',
      icon: Cloud,
      color: 'from-emerald-400 to-teal-500',
      image: 'https://images.pexels.com/photos/325229/pexels-photo-325229.jpeg?auto=compress&cs=tinysrgb&w=400&h=250&fit=crop',
      technologies: ['AWS', 'Docker', 'Kubernetes', 'Jenkins', 'Terraform'],
      description: 'Learn cloud infrastructure and deployment automation',
      duration: '4 months',
      level: 'Intermediate to Advanced'
    }
  ];

  return (
    <section id="features-section" className="py-20 px-6 relative overflow-hidden">
      {/* WORLD-CLASS ANIMATED BACKGROUND */}
      <div className="absolute inset-0">
        {/* Dynamic Mouse-Following Gradient */}
        <div 
          className="absolute w-[600px] h-[600px] bg-gradient-to-r from-indigo-500/15 via-violet-500/15 via-fuchsia-500/15 to-rose-500/15 rounded-full blur-3xl transition-all duration-1000 ease-out pointer-events-none"
          style={{
            left: mousePosition.x - 300,
            top: mousePosition.y - 300,
          }}
        />

        {/* Premium Background Layers */}
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-indigo-500/8 via-violet-500/8 via-fuchsia-500/8 to-rose-500/8"></div>
        
        {/* Enhanced Floating Particles */}
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-twinkle-premium"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${2 + Math.random() * 2}s`
            }}
          >
            <div className={`w-2 h-2 ${['bg-gradient-to-r from-indigo-400 to-violet-500', 'bg-gradient-to-r from-fuchsia-500 to-rose-500', 'bg-gradient-to-r from-amber-400 to-orange-500', 'bg-gradient-to-r from-emerald-400 to-teal-500'][Math.floor(Math.random() * 4)]} rounded-full opacity-40 blur-sm`}></div>
          </div>
        ))}

        {/* Tech Icons Floating */}
        {[Globe, Shield, Layers, Cpu, Database].map((Icon, i) => (
          <div
            key={i}
            className="absolute animate-float-tech opacity-20"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 4}s`,
              animationDuration: `${8 + Math.random() * 4}s`
            }}
          >
            <Icon className="w-8 h-8 text-indigo-400" />
          </div>
        ))}
      </div>

      <div className="container mx-auto relative z-10">
        {/* COMPACT SECTION HEADER */}
        <div className={`text-center mb-16 transition-all duration-2000 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
          <div className="inline-block p-4 bg-gradient-to-r from-indigo-500/30 to-violet-500/30 rounded-2xl backdrop-blur-xl border-2 border-indigo-400/40 mb-8 shadow-xl shadow-indigo-500/30">
            <Star className="w-12 h-12 text-indigo-300 animate-pulse-premium" />
          </div>
          <h2 className="text-4xl md:text-6xl font-black text-white mb-8">
            Why Choose{' '}
            <span className="bg-gradient-to-r from-indigo-400 via-violet-400 via-fuchsia-400 via-rose-400 to-amber-400 bg-clip-text text-transparent animate-rainbow-gradient-premium">
              CodeBind?
            </span>
          </h2>
          <p className="text-xl md:text-2xl text-gray-200 max-w-4xl mx-auto leading-relaxed font-light">
            We don't just teach code – we build <span className="text-indigo-400 font-bold">careers</span>, 
            shape <span className="text-violet-400 font-bold">futures</span>, and create 
            <span className="text-fuchsia-400 font-bold"> tech leaders</span> who will define tomorrow's digital landscape.
          </p>
        </div>

        {/* COMPACT FEATURES GRID */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-24">
          {features.map((feature, index) => (
            <div
              key={index}
              className={`group relative p-6 bg-gradient-to-br from-white/10 via-white/5 to-white/10 backdrop-blur-xl rounded-2xl border border-white/20 hover:bg-gradient-to-br hover:from-white/20 hover:via-white/10 hover:to-white/20 transition-all duration-1000 hover:transform hover:scale-105 hover:shadow-xl overflow-hidden cursor-pointer ${isVisible ? `animate-slideInUp-premium ${feature.delay}` : 'opacity-0 translate-y-20'}`}
            >
              {/* Enhanced Background Image */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-30 transition-all duration-1000 rounded-2xl overflow-hidden">
                <img 
                  src={feature.image} 
                  alt={feature.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-br from-slate-950/60 to-slate-950/90"></div>
              </div>

              {/* Premium Animated Border */}
              <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-transparent via-white/30 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-1000 animate-border-flow-premium"></div>
              
              {/* Premium Badge */}
              <div className="absolute top-3 right-3 px-2 py-1 bg-gradient-to-r from-indigo-400/90 to-violet-500/90 text-white text-xs font-bold rounded-full opacity-0 group-hover:opacity-100 transition-all duration-700 animate-bounce">
                {feature.badge}
              </div>

              <div className="relative z-10">
                {/* Enhanced Icon Container */}
                <div className={`inline-block p-4 bg-gradient-to-r ${feature.color} rounded-2xl mb-6 group-hover:scale-125 group-hover:rotate-12 transition-all duration-700 shadow-xl relative overflow-hidden`}>
                  <feature.icon className="w-8 h-8 text-white relative z-10" />
                  <div className="absolute inset-0 bg-white/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                </div>
                
                {/* Enhanced Typography */}
                <h3 className="text-2xl font-bold text-white mb-4 group-hover:text-indigo-300 transition-colors duration-700">
                  {feature.title}
                </h3>
                
                <p className="text-gray-300 leading-relaxed text-base group-hover:text-gray-200 transition-colors duration-700 mb-4">
                  {feature.description}
                </p>

                {/* Stats Badge */}
                <div className={`inline-block px-3 py-1 bg-gradient-to-r ${feature.color} text-white text-sm font-bold rounded-full opacity-80 group-hover:opacity-100 transition-opacity duration-500`}>
                  {feature.stats}
                </div>

                {/* Enhanced Hover Effect Particles */}
                <div className="absolute top-4 right-4 opacity-0 group-hover:opacity-100 transition-opacity duration-700">
                  {[...Array(3)].map((_, i) => (
                    <div
                      key={i}
                      className="absolute w-1 h-1 bg-gradient-to-r from-indigo-400 to-violet-500 rounded-full animate-bounce"
                      style={{
                        right: `${i * 8}px`,
                        animationDelay: `${i * 0.2}s`
                      }}
                    />
                  ))}
                </div>
              </div>

              {/* Premium Glow Effect */}
              <div className={`absolute inset-0 bg-gradient-to-r ${feature.color} opacity-0 group-hover:opacity-20 blur-xl transition-all duration-1000`}></div>
            </div>
          ))}
        </div>

        {/* COMPACT PROGRAM TRACKS */}
        <div className={`transition-all duration-2000 delay-700 ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0'}`}>
          <div className="text-center mb-16">
            <h3 className="text-3xl md:text-5xl font-black text-white mb-6">
              Choose Your{' '}
              <span className="bg-gradient-to-r from-indigo-400 via-violet-400 via-fuchsia-400 to-rose-400 bg-clip-text text-transparent animate-rainbow-gradient-premium">
                Specialization
              </span>
            </h3>
            <p className="text-lg md:text-xl text-gray-200 max-w-3xl mx-auto font-light">
              Dive deep into cutting-edge technologies with our specialized tracks designed for the future of tech innovation.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {tracks.map((track, index) => (
              <div
                key={index}
                className="group relative p-6 bg-gradient-to-br from-white/15 via-white/10 to-white/5 rounded-2xl border-2 border-white/20 text-center hover:from-white/25 hover:via-white/20 hover:to-white/15 hover:border-white/40 transition-all duration-700 cursor-pointer overflow-hidden hover:scale-105 hover:shadow-xl backdrop-blur-xl"
              >
                {/* Enhanced Background Image */}
                <div className="absolute inset-0 opacity-0 group-hover:opacity-40 transition-all duration-1000 rounded-2xl overflow-hidden">
                  <img 
                    src={track.image} 
                    alt={track.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-br from-slate-950/70 to-slate-950/90"></div>
                </div>

                <div className="relative z-10">
                  {/* Enhanced Icon */}
                  <div className={`w-16 h-16 bg-gradient-to-r ${track.color} rounded-2xl mx-auto mb-4 flex items-center justify-center group-hover:scale-125 group-hover:rotate-12 transition-all duration-700 shadow-xl relative overflow-hidden`}>
                    <track.icon className="w-8 h-8 text-white relative z-10" />
                    <div className="absolute inset-0 bg-white/20 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
                  </div>
                  
                  {/* Enhanced Content */}
                  <h4 className="text-xl font-bold text-white mb-2 group-hover:text-indigo-300 transition-colors duration-500">
                    {track.name}
                  </h4>
                  
                  <p className="text-gray-400 text-sm mb-3 leading-relaxed group-hover:text-gray-300 transition-colors duration-500">
                    {track.description}
                  </p>

                  {/* Duration and Level */}
                  <div className="flex justify-between items-center mb-3 text-xs">
                    <span className="text-indigo-400 font-semibold">{track.duration}</span>
                    <span className="text-violet-400 font-semibold">{track.level}</span>
                  </div>
                  
                  {/* Enhanced Technology Tags */}
                  <div className="flex flex-wrap gap-1 justify-center">
                    {track.technologies.map((tech, techIndex) => (
                      <span
                        key={techIndex}
                        className={`px-2 py-1 bg-gradient-to-r ${track.color} text-white rounded-full text-xs font-semibold group-hover:scale-110 transition-transform duration-300 shadow-lg`}
                        style={{ animationDelay: `${techIndex * 0.1}s` }}
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Premium Corner Accent */}
                <div className="absolute top-0 right-0 w-16 h-16 bg-gradient-to-br from-indigo-400/30 to-transparent rounded-bl-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-700"></div>
                
                {/* Premium Glow Effect */}
                <div className={`absolute inset-0 bg-gradient-to-r ${track.color} opacity-0 group-hover:opacity-15 blur-xl transition-all duration-1000`}></div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <style jsx>{`
        @keyframes slideInUp-premium {
          from {
            opacity: 0;
            transform: translateY(60px) scale(0.9);
          }
          to {
            opacity: 1;
            transform: translateY(0) scale(1);
          }
        }
        
        @keyframes twinkle-premium {
          0%, 100% {
            opacity: 0.2;
            transform: scale(1) rotate(0deg);
          }
          50% {
            opacity: 1;
            transform: scale(2) rotate(180deg);
          }
        }
        
        @keyframes border-flow-premium {
          0% {
            background-position: 0% 50%;
          }
          100% {
            background-position: 100% 50%;
          }
        }
        
        @keyframes rainbow-gradient-premium {
          0%, 100% {
            background-size: 600% 600%;
            background-position: 0% 50%;
          }
          25% {
            background-position: 100% 50%;
          }
          50% {
            background-position: 100% 100%;
          }
          75% {
            background-position: 0% 100%;
          }
        }
        
        @keyframes pulse-premium {
          0%, 100% {
            opacity: 0.8;
            transform: scale(1);
          }
          50% {
            opacity: 1;
            transform: scale(1.1);
          }
        }
        
        @keyframes float-tech {
          0%, 100% {
            transform: translateY(0px) rotate(0deg) scale(1);
            opacity: 0.2;
          }
          50% {
            transform: translateY(-50px) rotate(180deg) scale(1.5);
            opacity: 0.6;
          }
        }
        
        .animate-slideInUp-premium {
          animation: slideInUp-premium 1s ease-out forwards;
        }
        
        .animate-twinkle-premium {
          animation: twinkle-premium 3s ease-in-out infinite;
        }
        
        .animate-border-flow-premium {
          animation: border-flow-premium 3s linear infinite;
        }
        
        .animate-rainbow-gradient-premium {
          animation: rainbow-gradient-premium 5s ease infinite;
        }
        
        .animate-pulse-premium {
          animation: pulse-premium 3s ease-in-out infinite;
        }
        
        .animate-float-tech {
          animation: float-tech 15s ease-in-out infinite;
        }
        
        .delay-100 { animation-delay: 0.1s; }
        .delay-200 { animation-delay: 0.2s; }
        .delay-300 { animation-delay: 0.3s; }
        .delay-400 { animation-delay: 0.4s; }
        .delay-500 { animation-delay: 0.5s; }
        .delay-600 { animation-delay: 0.6s; }
      `}</style>
    </section>
  );
};

export default Features;