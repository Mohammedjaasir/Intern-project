import React, { useState, useEffect } from 'react';
import { X, User, Mail, Phone, GraduationCap, BookOpen, Calendar, Code, Heart, Sparkles, Star, Zap, Trophy, Rocket } from 'lucide-react';

interface FormData {
  name: string;
  email: string;
  phone: string;
  university: string;
  course: string;
  year: string;
  skills: string;
  motivation: string;
}

interface EnrollmentFormProps {
  onSubmit: (data: FormData) => void;
  onClose: () => void;
}

const EnrollmentForm: React.FC<EnrollmentFormProps> = ({ onSubmit, onClose }) => {
  const [formData, setFormData] = useState<FormData>({
    name: '',
    email: '',
    phone: '',
    university: '',
    course: '',
    year: '',
    skills: '',
    motivation: ''
  });

  const [errors, setErrors] = useState<Partial<FormData>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isVisible, setIsVisible] = useState(false);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [focusedField, setFocusedField] = useState<string | null>(null);

  useEffect(() => {
    setIsVisible(true);
    const handleMouseMove = (e: MouseEvent) => {
      setMousePosition({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const validateForm = (): boolean => {
    const newErrors: Partial<FormData> = {};

    if (!formData.name.trim()) newErrors.name = 'Name is required';
    if (!formData.email.trim()) newErrors.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = 'Email is invalid';
    if (!formData.phone.trim()) newErrors.phone = 'Phone is required';
    else if (!/^\d{10}$/.test(formData.phone.replace(/\D/g, ''))) newErrors.phone = 'Phone must be 10 digits';
    if (!formData.university.trim()) newErrors.university = 'University is required';
    if (!formData.course.trim()) newErrors.course = 'Course is required';
    if (!formData.year.trim()) newErrors.year = 'Year is required';
    if (!formData.skills.trim()) newErrors.skills = 'Skills are required';
    if (!formData.motivation.trim()) newErrors.motivation = 'Motivation is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;

    setIsSubmitting(true);
    
    // Enhanced loading simulation with progress
    setTimeout(() => {
      onSubmit(formData);
      setIsSubmitting(false);
    }, 3000);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    if (errors[name as keyof FormData]) {
      setErrors(prev => ({ ...prev, [name]: undefined }));
    }
  };

  const handleFocus = (fieldName: string) => {
    setFocusedField(fieldName);
  };

  const handleBlur = () => {
    setFocusedField(null);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md">
      {/* Dynamic Mouse-Following Gradient */}
      <div 
        className="absolute w-96 h-96 bg-gradient-to-r from-cyan-500/30 to-purple-500/30 rounded-full blur-3xl transition-all duration-1000 ease-out pointer-events-none"
        style={{
          left: mousePosition.x - 192,
          top: mousePosition.y - 192,
        }}
      />

      {/* Animated Background Elements */}
      <div className="absolute inset-0 overflow-hidden">
        {/* Hero Background Image */}
        <div className="absolute inset-0">
          <img 
            src="https://images.pexels.com/photos/3861969/pexels-photo-3861969.jpeg?auto=compress&cs=tinysrgb&w=1920&h=1080&fit=crop"
            alt="Coding workspace"
            className="w-full h-full object-cover opacity-5"
          />
          <div className="absolute inset-0 bg-gradient-to-br from-slate-900/95 via-purple-900/95 to-slate-900/95"></div>
        </div>

        {/* Floating Particles */}
        {[...Array(50)].map((_, i) => (
          <div
            key={i}
            className="absolute w-1 h-1 bg-gradient-to-r from-cyan-400 via-purple-500 to-pink-500 rounded-full opacity-40 animate-twinkle"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${2 + Math.random() * 3}s`
            }}
          />
        ))}

        {/* Floating Code Elements */}
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute text-cyan-400/20 font-mono text-lg animate-float opacity-30"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${4 + Math.random() * 3}s`
            }}
          >
            {['</>', '{}', '[]', '()', '&&', '||', '=>', '++', 'const', 'let', 'var', 'function'][Math.floor(Math.random() * 12)]}
          </div>
        ))}
      </div>

      <div className={`w-full max-w-6xl max-h-[95vh] overflow-y-auto bg-white/10 backdrop-blur-xl rounded-3xl border border-white/20 shadow-2xl transition-all duration-1000 ${isVisible ? 'scale-100 opacity-100' : 'scale-95 opacity-0'}`}>
        {/* Ultra Enhanced Header */}
        <div className="relative flex items-center justify-between p-10 border-b border-white/20 bg-gradient-to-r from-cyan-500/10 via-purple-500/10 via-pink-500/10 to-orange-500/10 overflow-hidden">
          {/* Background Pattern */}
          <div className="absolute inset-0 opacity-10">
            <img 
              src="https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=800&h=400&fit=crop"
              alt="Team collaboration"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 via-purple-500/20 to-pink-500/20"></div>
          </div>

          <div className="relative z-10 flex items-center space-x-6">
            {/* Animated Logo */}
            <div className="relative">
              <div className="p-4 bg-gradient-to-r from-cyan-500 via-blue-500 via-purple-600 to-pink-600 rounded-3xl animate-gradient-rotate shadow-2xl">
                <Sparkles className="w-12 h-12 text-white animate-pulse" />
              </div>
              <div className="absolute -top-2 -right-2 w-6 h-6 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center animate-bounce">
                <Star className="w-3 h-3 text-white" />
              </div>
            </div>
            
            <div>
              <h2 className="text-5xl font-bold bg-gradient-to-r from-white via-cyan-200 via-purple-200 to-pink-200 bg-clip-text text-transparent animate-gradient-x">
                Join CodeBind Technologies
              </h2>
              <p className="text-gray-300 mt-2 text-xl font-medium">Transform your passion into profession ✨</p>
              <div className="flex items-center space-x-4 mt-3">
                <div className="flex items-center space-x-2">
                  <Trophy className="w-5 h-5 text-yellow-400" />
                  <span className="text-yellow-400 font-semibold">Premium Program</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Rocket className="w-5 h-5 text-cyan-400" />
                  <span className="text-cyan-400 font-semibold">Fast Track</span>
                </div>
              </div>
            </div>
          </div>

          <button
            onClick={onClose}
            className="relative z-10 p-4 text-gray-400 hover:text-white hover:bg-white/10 rounded-3xl transition-all duration-300 hover:scale-110 hover:rotate-90 group"
          >
            <X className="w-8 h-8" />
            <div className="absolute inset-0 bg-gradient-to-r from-red-500/20 to-pink-500/20 rounded-3xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
          </button>
          
          {/* Enhanced Floating Elements */}
          <div className="absolute top-6 right-32 animate-bounce delay-300">
            <Star className="w-8 h-8 text-yellow-400 opacity-60 animate-pulse" />
          </div>
          <div className="absolute bottom-6 left-32 animate-bounce delay-700">
            <Zap className="w-6 h-6 text-pink-400 opacity-60 animate-pulse" />
          </div>
          <div className="absolute top-1/2 right-16 animate-bounce delay-1000">
            <Code className="w-7 h-7 text-cyan-400 opacity-60 animate-pulse" />
          </div>
        </div>

        {/* Enhanced Form */}
        <form onSubmit={handleSubmit} className="p-10 space-y-12">
          {/* Personal Information Section */}
          <div className="space-y-10">
            <div className="text-center">
              <h3 className="text-4xl font-bold text-white flex items-center justify-center space-x-4 mb-4">
                <div className="p-3 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-2xl animate-pulse">
                  <User className="w-8 h-8 text-white" />
                </div>
                <span className="bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
                  Personal Information
                </span>
              </h3>
              <p className="text-gray-300 text-lg">Let's get to know you better! 🚀</p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
              {/* Name Field */}
              <div className="space-y-4 group">
                <label className="flex items-center space-x-3 text-white font-bold text-xl">
                  <div className="p-2 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-xl">
                    <User className="w-5 h-5 text-white" />
                  </div>
                  <span>Full Name</span>
                  {focusedField === 'name' && <Sparkles className="w-5 h-5 text-cyan-400 animate-spin" />}
                </label>
                <div className="relative">
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    onFocus={() => handleFocus('name')}
                    onBlur={handleBlur}
                    className="w-full px-8 py-5 bg-white/10 border-2 border-white/20 rounded-2xl text-white placeholder-gray-400 focus:outline-none focus:border-cyan-500 focus:bg-white/20 focus:shadow-lg focus:shadow-cyan-500/25 transition-all duration-500 hover:border-white/40 text-xl group-hover:shadow-lg group-hover:shadow-cyan-500/25"
                    placeholder="Enter your full name"
                  />
                  {focusedField === 'name' && (
                    <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-cyan-500/20 to-blue-500/20 pointer-events-none animate-pulse"></div>
                  )}
                </div>
                {errors.name && (
                  <p className="text-red-400 text-sm flex items-center space-x-2 animate-shake">
                    <span>⚠️</span><span>{errors.name}</span>
                  </p>
                )}
              </div>

              {/* Email Field */}
              <div className="space-y-4 group">
                <label className="flex items-center space-x-3 text-white font-bold text-xl">
                  <div className="p-2 bg-gradient-to-r from-purple-500 to-pink-500 rounded-xl">
                    <Mail className="w-5 h-5 text-white" />
                  </div>
                  <span>Email Address</span>
                  {focusedField === 'email' && <Sparkles className="w-5 h-5 text-purple-400 animate-spin" />}
                </label>
                <div className="relative">
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    onFocus={() => handleFocus('email')}
                    onBlur={handleBlur}
                    className="w-full px-8 py-5 bg-white/10 border-2 border-white/20 rounded-2xl text-white placeholder-gray-400 focus:outline-none focus:border-purple-500 focus:bg-white/20 focus:shadow-lg focus:shadow-purple-500/25 transition-all duration-500 hover:border-white/40 text-xl group-hover:shadow-lg group-hover:shadow-purple-500/25"
                    placeholder="Enter your email"
                  />
                  {focusedField === 'email' && (
                    <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-purple-500/20 to-pink-500/20 pointer-events-none animate-pulse"></div>
                  )}
                </div>
                {errors.email && (
                  <p className="text-red-400 text-sm flex items-center space-x-2 animate-shake">
                    <span>⚠️</span><span>{errors.email}</span>
                  </p>
                )}
              </div>

              {/* Phone Field */}
              <div className="space-y-4 group">
                <label className="flex items-center space-x-3 text-white font-bold text-xl">
                  <div className="p-2 bg-gradient-to-r from-emerald-500 to-teal-500 rounded-xl">
                    <Phone className="w-5 h-5 text-white" />
                  </div>
                  <span>Phone Number</span>
                  {focusedField === 'phone' && <Sparkles className="w-5 h-5 text-emerald-400 animate-spin" />}
                </label>
                <div className="relative">
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    onFocus={() => handleFocus('phone')}
                    onBlur={handleBlur}
                    className="w-full px-8 py-5 bg-white/10 border-2 border-white/20 rounded-2xl text-white placeholder-gray-400 focus:outline-none focus:border-emerald-500 focus:bg-white/20 focus:shadow-lg focus:shadow-emerald-500/25 transition-all duration-500 hover:border-white/40 text-xl group-hover:shadow-lg group-hover:shadow-emerald-500/25"
                    placeholder="Enter your phone number"
                  />
                  {focusedField === 'phone' && (
                    <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-emerald-500/20 to-teal-500/20 pointer-events-none animate-pulse"></div>
                  )}
                </div>
                {errors.phone && (
                  <p className="text-red-400 text-sm flex items-center space-x-2 animate-shake">
                    <span>⚠️</span><span>{errors.phone}</span>
                  </p>
                )}
              </div>

              {/* University Field */}
              <div className="space-y-4 group">
                <label className="flex items-center space-x-3 text-white font-bold text-xl">
                  <div className="p-2 bg-gradient-to-r from-orange-500 to-red-500 rounded-xl">
                    <GraduationCap className="w-5 h-5 text-white" />
                  </div>
                  <span>University/College</span>
                  {focusedField === 'university' && <Sparkles className="w-5 h-5 text-orange-400 animate-spin" />}
                </label>
                <div className="relative">
                  <input
                    type="text"
                    name="university"
                    value={formData.university}
                    onChange={handleChange}
                    onFocus={() => handleFocus('university')}
                    onBlur={handleBlur}
                    className="w-full px-8 py-5 bg-white/10 border-2 border-white/20 rounded-2xl text-white placeholder-gray-400 focus:outline-none focus:border-orange-500 focus:bg-white/20 focus:shadow-lg focus:shadow-orange-500/25 transition-all duration-500 hover:border-white/40 text-xl group-hover:shadow-lg group-hover:shadow-orange-500/25"
                    placeholder="Enter your university name"
                  />
                  {focusedField === 'university' && (
                    <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-orange-500/20 to-red-500/20 pointer-events-none animate-pulse"></div>
                  )}
                </div>
                {errors.university && (
                  <p className="text-red-400 text-sm flex items-center space-x-2 animate-shake">
                    <span>⚠️</span><span>{errors.university}</span>
                  </p>
                )}
              </div>

              {/* Course Field */}
              <div className="space-y-4 group">
                <label className="flex items-center space-x-3 text-white font-bold text-xl">
                  <div className="p-2 bg-gradient-to-r from-pink-500 to-rose-500 rounded-xl">
                    <BookOpen className="w-5 h-5 text-white" />
                  </div>
                  <span>Course/Degree</span>
                  {focusedField === 'course' && <Sparkles className="w-5 h-5 text-pink-400 animate-spin" />}
                </label>
                <div className="relative">
                  <input
                    type="text"
                    name="course"
                    value={formData.course}
                    onChange={handleChange}
                    onFocus={() => handleFocus('course')}
                    onBlur={handleBlur}
                    className="w-full px-8 py-5 bg-white/10 border-2 border-white/20 rounded-2xl text-white placeholder-gray-400 focus:outline-none focus:border-pink-500 focus:bg-white/20 focus:shadow-lg focus:shadow-pink-500/25 transition-all duration-500 hover:border-white/40 text-xl group-hover:shadow-lg group-hover:shadow-pink-500/25"
                    placeholder="e.g., Computer Science, IT, Engineering"
                  />
                  {focusedField === 'course' && (
                    <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-pink-500/20 to-rose-500/20 pointer-events-none animate-pulse"></div>
                  )}
                </div>
                {errors.course && (
                  <p className="text-red-400 text-sm flex items-center space-x-2 animate-shake">
                    <span>⚠️</span><span>{errors.course}</span>
                  </p>
                )}
              </div>

              {/* Year Field */}
              <div className="space-y-4 group">
                <label className="flex items-center space-x-3 text-white font-bold text-xl">
                  <div className="p-2 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-xl">
                    <Calendar className="w-5 h-5 text-white" />
                  </div>
                  <span>Current Year</span>
                  {focusedField === 'year' && <Sparkles className="w-5 h-5 text-indigo-400 animate-spin" />}
                </label>
                <div className="relative">
                  <select
                    name="year"
                    value={formData.year}
                    onChange={handleChange}
                    onFocus={() => handleFocus('year')}
                    onBlur={handleBlur}
                    className="w-full px-8 py-5 bg-white/10 border-2 border-white/20 rounded-2xl text-white focus:outline-none focus:border-indigo-500 focus:bg-white/20 focus:shadow-lg focus:shadow-indigo-500/25 transition-all duration-500 hover:border-white/40 text-xl group-hover:shadow-lg group-hover:shadow-indigo-500/25"
                  >
                    <option value="" className="bg-gray-800 text-white">Select your year</option>
                    <option value="1st Year" className="bg-gray-800 text-white">1st Year</option>
                    <option value="2nd Year" className="bg-gray-800 text-white">2nd Year</option>
                    <option value="3rd Year" className="bg-gray-800 text-white">3rd Year</option>
                    <option value="4th Year" className="bg-gray-800 text-white">4th Year</option>
                    <option value="Recent Graduate" className="bg-gray-800 text-white">Recent Graduate</option>
                  </select>
                  {focusedField === 'year' && (
                    <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-indigo-500/20 to-purple-500/20 pointer-events-none animate-pulse"></div>
                  )}
                </div>
                {errors.year && (
                  <p className="text-red-400 text-sm flex items-center space-x-2 animate-shake">
                    <span>⚠️</span><span>{errors.year}</span>
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Skills & Motivation Section */}
          <div className="space-y-10">
            <div className="text-center">
              <h3 className="text-4xl font-bold text-white flex items-center justify-center space-x-4 mb-4">
                <div className="p-3 bg-gradient-to-r from-purple-500 to-pink-500 rounded-2xl animate-pulse">
                  <Code className="w-8 h-8 text-white" />
                </div>
                <span className="bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent">
                  Skills & Motivation
                </span>
              </h3>
              <p className="text-gray-300 text-lg">Show us your passion and expertise! 💻</p>
            </div>

            {/* Skills Field */}
            <div className="space-y-4 group">
              <label className="flex items-center space-x-3 text-white font-bold text-xl">
                <div className="p-2 bg-gradient-to-r from-cyan-500 to-blue-500 rounded-xl">
                  <Code className="w-5 h-5 text-white" />
                </div>
                <span>Technical Skills</span>
                {focusedField === 'skills' && <Sparkles className="w-5 h-5 text-cyan-400 animate-spin" />}
              </label>
              <div className="relative">
                <input
                  type="text"
                  name="skills"
                  value={formData.skills}
                  onChange={handleChange}
                  onFocus={() => handleFocus('skills')}
                  onBlur={handleBlur}
                  className="w-full px-8 py-5 bg-white/10 border-2 border-white/20 rounded-2xl text-white placeholder-gray-400 focus:outline-none focus:border-cyan-500 focus:bg-white/20 focus:shadow-lg focus:shadow-cyan-500/25 transition-all duration-500 hover:border-white/40 text-xl group-hover:shadow-lg group-hover:shadow-cyan-500/25"
                  placeholder="e.g., JavaScript, React, Python, Java, C++, Node.js"
                />
                {focusedField === 'skills' && (
                  <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-cyan-500/20 to-blue-500/20 pointer-events-none animate-pulse"></div>
                )}
              </div>
              {errors.skills && (
                <p className="text-red-400 text-sm flex items-center space-x-2 animate-shake">
                  <span>⚠️</span><span>{errors.skills}</span>
                </p>
              )}
            </div>

            {/* Motivation Field */}
            <div className="space-y-4 group">
              <label className="flex items-center space-x-3 text-white font-bold text-xl">
                <div className="p-2 bg-gradient-to-r from-pink-500 to-rose-500 rounded-xl">
                  <Heart className="w-5 h-5 text-white" />
                </div>
                <span>Why do you want to join CodeBind?</span>
                {focusedField === 'motivation' && <Sparkles className="w-5 h-5 text-pink-400 animate-spin" />}
              </label>
              <div className="relative">
                <textarea
                  name="motivation"
                  value={formData.motivation}
                  onChange={handleChange}
                  onFocus={() => handleFocus('motivation')}
                  onBlur={handleBlur}
                  rows={6}
                  className="w-full px-8 py-5 bg-white/10 border-2 border-white/20 rounded-2xl text-white placeholder-gray-400 focus:outline-none focus:border-pink-500 focus:bg-white/20 focus:shadow-lg focus:shadow-pink-500/25 transition-all duration-500 hover:border-white/40 text-xl resize-none group-hover:shadow-lg group-hover:shadow-pink-500/25"
                  placeholder="Tell us about your goals, dreams, and what drives your passion for technology..."
                />
                {focusedField === 'motivation' && (
                  <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-pink-500/20 to-rose-500/20 pointer-events-none animate-pulse"></div>
                )}
              </div>
              {errors.motivation && (
                <p className="text-red-400 text-sm flex items-center space-x-2 animate-shake">
                  <span>⚠️</span><span>{errors.motivation}</span>
                </p>
              )}
            </div>
          </div>

          {/* Ultra Enhanced Submit Button */}
          <div className="text-center">
            <button
              type="submit"
              disabled={isSubmitting}
              className="group relative px-16 py-6 bg-gradient-to-r from-cyan-500 via-blue-500 via-purple-600 to-pink-600 text-white font-bold text-2xl rounded-3xl hover:from-cyan-600 hover:via-blue-600 hover:via-purple-700 hover:to-pink-700 disabled:opacity-50 disabled:cursor-not-allowed transform hover:scale-110 transition-all duration-500 shadow-2xl hover:shadow-cyan-500/25 overflow-hidden animate-gradient-rotate"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-white/20 via-transparent to-white/20 opacity-0 group-hover:opacity-100 transition-opacity duration-500 animate-shimmer"></div>
              
              {isSubmitting ? (
                <div className="flex items-center justify-center space-x-4 relative z-10">
                  <div className="w-8 h-8 border-4 border-white/30 border-t-white rounded-full animate-spin"></div>
                  <span>Processing Your Application...</span>
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-white rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-white rounded-full animate-bounce delay-100"></div>
                    <div className="w-2 h-2 bg-white rounded-full animate-bounce delay-200"></div>
                  </div>
                </div>
              ) : (
                <div className="flex items-center justify-center space-x-4 relative z-10">
                  <Rocket className="w-8 h-8 group-hover:animate-bounce" />
                  <span>Complete Enrollment</span>
                  <Sparkles className="w-8 h-8 group-hover:animate-spin" />
                </div>
              )}

              {/* Button Glow Effect */}
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-400/20 via-purple-600/20 to-pink-600/20 blur-xl group-hover:blur-2xl transition-all duration-500"></div>
            </button>

            <p className="text-gray-400 mt-6 text-lg">
              🚀 Join <span className="text-cyan-400 font-semibold">1000+</span> successful students who transformed their careers with CodeBind!
            </p>
          </div>
        </form>
      </div>

      <style jsx>{`
        @keyframes twinkle {
          0%, 100% {
            opacity: 0.3;
            transform: scale(1);
          }
          50% {
            opacity: 1;
            transform: scale(1.5);
          }
        }
        
        @keyframes float {
          0%, 100% {
            transform: translateY(0px) rotate(0deg);
          }
          50% {
            transform: translateY(-30px) rotate(180deg);
          }
        }
        
        @keyframes gradient-rotate {
          0% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
          100% {
            background-position: 0% 50%;
          }
        }
        
        @keyframes gradient-x {
          0%, 100% {
            background-size: 200% 200%;
            background-position: left center;
          }
          50% {
            background-size: 200% 200%;
            background-position: right center;
          }
        }
        
        @keyframes shimmer {
          0% {
            transform: translateX(-100%);
          }
          100% {
            transform: translateX(100%);
          }
        }
        
        @keyframes shake {
          0%, 100% {
            transform: translateX(0);
          }
          25% {
            transform: translateX(-5px);
          }
          75% {
            transform: translateX(5px);
          }
        }
        
        .animate-twinkle {
          animation: twinkle 2s ease-in-out infinite;
        }
        
        .animate-float {
          animation: float 6s ease-in-out infinite;
        }
        
        .animate-gradient-rotate {
          background-size: 400% 400%;
          animation: gradient-rotate 3s ease infinite;
        }
        
        .animate-gradient-x {
          animation: gradient-x 3s ease infinite;
        }
        
        .animate-shimmer {
          animation: shimmer 2s ease-in-out infinite;
        }
        
        .animate-shake {
          animation: shake 0.5s ease-in-out;
        }
      `}</style>
    </div>
  );
};

export default EnrollmentForm;