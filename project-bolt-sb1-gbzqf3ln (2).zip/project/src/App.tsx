import React, { useState } from 'react';
import Header from './components/Header';
import Hero from './components/Hero';
import Features from './components/Features';
import EnrollmentForm from './components/EnrollmentForm';
import SuccessModal from './components/SuccessModal';
import Footer from './components/Footer';

interface Student {
  id: string;
  name: string;
  email: string;
  phone: string;
  university: string;
  course: string;
  year: string;
  skills: string;
  motivation: string;
  registeredAt: string;
}

function App() {
  const [showForm, setShowForm] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [registeredStudent, setRegisteredStudent] = useState<Student | null>(null);

  const handleEnrollClick = () => {
    setShowForm(true);
  };

  const handleFormSubmit = (studentData: Omit<Student, 'id' | 'registeredAt'>) => {
    const student: Student = {
      ...studentData,
      id: Date.now().toString(),
      registeredAt: new Date().toISOString(),
    };

    // Save to localStorage (simulating database)
    const existingStudents = JSON.parse(localStorage.getItem('codebind_students') || '[]');
    existingStudents.push(student);
    localStorage.setItem('codebind_students', JSON.stringify(existingStudents));

    setRegisteredStudent(student);
    setShowForm(false);
    setShowSuccess(true);
  };

  const handleCloseSuccess = () => {
    setShowSuccess(false);
    setRegisteredStudent(null);
  };

  const handleCloseForm = () => {
    setShowForm(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 via-purple-950 to-slate-950 relative overflow-hidden">
      {/* Ultra Enhanced Animated Background Elements */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-br from-indigo-600/8 via-violet-600/8 via-fuchsia-600/8 to-rose-600/8"></div>
        
        {/* Large Gradient Orbs */}
        <div className="absolute top-1/4 left-1/4 w-[600px] h-[600px] bg-gradient-to-r from-indigo-400/12 via-violet-500/12 to-fuchsia-600/12 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-gradient-to-r from-fuchsia-500/12 via-rose-500/12 to-amber-500/12 rounded-full blur-3xl animate-pulse delay-1000"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-gradient-to-r from-violet-500/8 via-fuchsia-500/8 via-rose-500/8 to-indigo-500/8 rounded-full blur-3xl animate-ping"></div>
        
        {/* Beautiful Gradient Rings */}
        <div className="absolute top-20 right-20 w-96 h-96 border-4 border-gradient-rainbow rounded-full animate-spin-slow opacity-20"></div>
        <div className="absolute bottom-20 left-20 w-64 h-64 border-4 border-gradient-rainbow rounded-full animate-spin-reverse opacity-15"></div>
        
        {/* Enhanced Floating Particles */}
        {[...Array(40)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-twinkle"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 5}s`,
              animationDuration: `${3 + Math.random() * 4}s`
            }}
          >
            <div className={`w-3 h-3 ${['bg-gradient-to-r from-indigo-400 to-violet-500', 'bg-gradient-to-r from-fuchsia-500 to-rose-500', 'bg-gradient-to-r from-amber-400 to-orange-500', 'bg-gradient-to-r from-emerald-400 to-teal-500', 'bg-gradient-to-r from-violet-400 to-fuchsia-500'][Math.floor(Math.random() * 5)]} rounded-full opacity-60 blur-sm`}></div>
          </div>
        ))}

        {/* Floating Geometric Shapes */}
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute animate-float-geometric opacity-30"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animationDelay: `${Math.random() * 3}s`,
              animationDuration: `${6 + Math.random() * 4}s`
            }}
          >
            <div className={`w-6 h-6 ${['bg-gradient-to-r from-indigo-400 to-violet-500', 'bg-gradient-to-r from-fuchsia-500 to-rose-500', 'bg-gradient-to-r from-amber-400 to-orange-500', 'bg-gradient-to-r from-emerald-400 to-teal-500'][Math.floor(Math.random() * 4)]} ${['rounded-full', 'rounded-lg', 'transform rotate-45'][Math.floor(Math.random() * 3)]} blur-sm`}></div>
          </div>
        ))}
      </div>

      <Header />
      {!showForm ? (
        <>
          <Hero onEnrollClick={handleEnrollClick} />
          <Features />
          <Footer />
        </>
      ) : (
        <EnrollmentForm onSubmit={handleFormSubmit} onClose={handleCloseForm} />
      )}
      {showSuccess && registeredStudent && (
        <SuccessModal student={registeredStudent} onClose={handleCloseSuccess} />
      )}

      <style jsx>{`
        @keyframes twinkle {
          0%, 100% {
            opacity: 0.3;
            transform: scale(1);
          }
          50% {
            opacity: 1;
            transform: scale(1.8);
          }
        }
        
        @keyframes float-geometric {
          0%, 100% {
            transform: translateY(0px) rotate(0deg) scale(1);
          }
          33% {
            transform: translateY(-25px) rotate(120deg) scale(1.3);
          }
          66% {
            transform: translateY(-15px) rotate(240deg) scale(0.7);
          }
        }
        
        @keyframes spin-slow {
          from {
            transform: rotate(0deg);
          }
          to {
            transform: rotate(360deg);
          }
        }
        
        @keyframes spin-reverse {
          from {
            transform: rotate(360deg);
          }
          to {
            transform: rotate(0deg);
          }
        }
        
        .animate-twinkle {
          animation: twinkle 3s ease-in-out infinite;
        }
        
        .animate-float-geometric {
          animation: float-geometric 8s ease-in-out infinite;
        }
        
        .animate-spin-slow {
          animation: spin-slow 25s linear infinite;
        }
        
        .animate-spin-reverse {
          animation: spin-reverse 20s linear infinite;
        }
      `}</style>
    </div>
  );
}

export default App;